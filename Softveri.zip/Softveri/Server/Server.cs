﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Server
{
    public class Server
    {
        private Socket serverSoket;

        public void PokreniServer() {
            try
            {
                this.serverSoket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                this.serverSoket.Bind(new IPEndPoint(IPAddress.Any,10000));
                this.serverSoket.Listen(5);
                Console.WriteLine("Server pokrenut!");

                while (true) {
                    Console.WriteLine("Cekamo klijenta!");
                    Socket klijentSoket = this.serverSoket.Accept();
                    Console.WriteLine("Klijent se prijavio!");

                    new ObradaKlijenta(klijentSoket).Obrada();
                }

            }
            catch (Exception ex)
            {

                Console.WriteLine("Server je vec pokrenut!");
            }
        }
    }
}
