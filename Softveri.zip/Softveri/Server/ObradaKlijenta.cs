﻿using Klasa;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Server
{
    public class ObradaKlijenta
    {
        private Socket socket;
        private NetworkStream stream;
        private BinaryFormatter formater;

        public ObradaKlijenta(Socket socket)
        {
            this.socket = socket;
            this.stream = new NetworkStream(socket);
            this.formater = new BinaryFormatter();
            //Thread nit = new Thread(Obrada);
            //nit.Start();
        }

        internal void Obrada()
        {
            try
            {
                bool kraj = false;

                while (!kraj) {
                    Zahtev zahtev = (Zahtev)this.formater.Deserialize(this.stream);
                    Odgovor odgovor = new Odgovor();

                    switch (zahtev.Operacija) {

                        case Operacija.Login:
                            Zaposleni z = (Zaposleni)zahtev.Podaci;
                            odgovor.Podaci = Kontroler.Kontroler.Instanca.PrijaviSe(z.KorisnickoIme, z.KorisnickaSifra);
                            odgovor.Uspesnost = true;
                            break;
                        case Operacija.Odjavi: break;
                        case Operacija.VratiProizvodjace:
                            odgovor.Podaci = Kontroler.Kontroler.Instanca.vratiProizvodjace();
                            odgovor.Uspesnost = true;
                            break;

                            //NALOG
                        case Operacija.UbaciNalog: odgovor.Podaci = Kontroler.Kontroler.Instanca.kreirajNalog((Nalog)zahtev.Podaci);
                            odgovor.Uspesnost = true;
                            break;
                        case Operacija.PromeniNalog:
                            odgovor.Podaci = Kontroler.Kontroler.Instanca.PromeniNalog((Nalog) zahtev.Podaci);
                            odgovor.Uspesnost = true;
                            break;
                        case Operacija.ObrisiNalog:
                            odgovor.Podaci = Kontroler.Kontroler.Instanca.ObrisiNalog((Nalog) zahtev.Podaci);
                            odgovor.Uspesnost = true;
                            break;
                        case Operacija.VratiSveNaloge:
                            odgovor.Podaci= Kontroler.Kontroler.Instanca.vratiSveNaloge();
                            odgovor.Uspesnost = true;
                            break;
                        case Operacija.PretraziNalog:
                            odgovor.Podaci = Kontroler.Kontroler.Instanca.PretragaNaloga(zahtev.Podaci.ToString());
                            odgovor.Uspesnost = true;
                            break;
                            //PROIZVOD
                        case Operacija.KreirajProizvod:
                            odgovor.Podaci = Kontroler.Kontroler.Instanca.napraviGamingProizvod2((GamingProizvod)zahtev.Podaci);
                            odgovor.Uspesnost = true;
                            break;
                        case Operacija.PromeniProizvod:
                            odgovor.Podaci= Kontroler.Kontroler.Instanca.promeniGamingProizvod((GamingProizvod)zahtev.Podaci);
                            odgovor.Uspesnost = true;
                            break;
                        case Operacija.IzbrisiProizvod:
                            odgovor.Podaci = Kontroler.Kontroler.Instanca.izbrisiGamingProizvod((GamingProizvod)zahtev.Podaci);
                            odgovor.Uspesnost = true;
                            break;
                        case Operacija.VratiSveProizvode:
                            odgovor.Podaci = Kontroler.Kontroler.Instanca.ucitajGamingProizvode();
                            odgovor.Uspesnost = true;
                            break;
                        case Operacija.PretraziProizvod:  odgovor.Podaci = Kontroler.Kontroler.Instanca.pretragaGamingProizvoda(zahtev.Podaci.ToString());
                            odgovor.Uspesnost = true;
                            break;
                            //NARUDZBENICA
                        case Operacija.UbaciNarudzbinu: break;
                        case Operacija.PromeniNarudzbinu:  break;
                        case Operacija.IzbrisiNarudzbinu: break;
                        
                        default:  kraj = true; break;

                    }
                    this.formater.Serialize(this.stream, odgovor);
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
            finally {
                this.socket.Shutdown(SocketShutdown.Both);
                this.socket.Close();
            }
        }
    }
}
