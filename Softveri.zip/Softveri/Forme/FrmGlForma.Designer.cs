﻿namespace Forme
{
    partial class frm_glavna
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties13 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties14 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_glavna));
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.pnl_top = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.btn_odjava = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btn_gmail = new Bunifu.Framework.UI.BunifuImageButton();
            this.btn_youtube = new Bunifu.Framework.UI.BunifuImageButton();
            this.btn_facebook = new Bunifu.Framework.UI.BunifuImageButton();
            this.btn_pretraga = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_zaposleniIme = new System.Windows.Forms.Label();
            this.pcb_slikaZaposlenog = new Bunifu.UI.WinForms.BunifuPictureBox();
            this.btn_proizvodi = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btn_narudzbenica = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btn_clanovi = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.pnl_selektovanoDugme = new System.Windows.Forms.Panel();
            this.pnl_left = new System.Windows.Forms.Panel();
            this.lbl_selektovaniNaziv = new System.Windows.Forms.Label();
            this.btn_Obrisi = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btn_kreiraj = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btn_promeni = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.dgv_podaci = new System.Windows.Forms.DataGridView();
            this.pnl_prikazElemenata = new System.Windows.Forms.Panel();
            this.lbl_clanskiBrojIzabranogClana = new System.Windows.Forms.Label();
            this.btn_ponistiPromene = new Bunifu.Framework.UI.BunifuThinButton2();
            this.txt_adresaIzabranogClana = new System.Windows.Forms.TextBox();
            this.txt_emailIzbranogClana = new System.Windows.Forms.TextBox();
            this.txt_telefonIzabranogClana = new System.Windows.Forms.TextBox();
            this.txt_prezimeIzabranogClana = new System.Windows.Forms.TextBox();
            this.txt_imeIzabranogClana = new System.Windows.Forms.TextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pnl_izabraniGamingProizvod = new System.Windows.Forms.Panel();
            this.lbl_ProizvodID = new System.Windows.Forms.Label();
            this.lbl_nazivProizvodjacaIzbProizvoda = new System.Windows.Forms.Label();
            this.btn_nazadProizvod = new Bunifu.Framework.UI.BunifuThinButton2();
            this.pnl_plusUMinusProizvodjac = new System.Windows.Forms.Panel();
            this.lbl_minusUPlusProiz = new System.Windows.Forms.Label();
            this.pnl_plusUMinusKarakteristike = new System.Windows.Forms.Panel();
            this.lbl_plusMinusKar = new System.Windows.Forms.Label();
            this.txt_karakteristikeIzabranogGamingProizvoda = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txt_kolicinaIzabranogGamingProizvoda = new System.Windows.Forms.TextBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.txt_cenaIzabranogGamingProizvoda = new System.Windows.Forms.TextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.pnl_podaciIzabranogProizvodjaca = new System.Windows.Forms.Panel();
            this.txt_adresaIzabranogProizvodjaca = new System.Windows.Forms.TextBox();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.txt_telefonIzabranogProizvodjac = new System.Windows.Forms.TextBox();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.lbl_modelGProizvoda = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.lbl_proizvodjacIzbProizvda = new System.Windows.Forms.Label();
            this.lbl_nazivGProizvoda = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.lbl_proizvodjacID = new System.Windows.Forms.Label();
            this.pnl_top.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_gmail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_youtube)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_facebook)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcb_slikaZaposlenog)).BeginInit();
            this.pnl_left.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_podaci)).BeginInit();
            this.pnl_prikazElemenata.SuspendLayout();
            this.pnl_izabraniGamingProizvod.SuspendLayout();
            this.pnl_plusUMinusProizvodjac.SuspendLayout();
            this.pnl_plusUMinusKarakteristike.SuspendLayout();
            this.pnl_podaciIzabranogProizvodjaca.SuspendLayout();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // pnl_top
            // 
            this.pnl_top.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.pnl_top.Controls.Add(this.label6);
            this.pnl_top.Controls.Add(this.btn_odjava);
            this.pnl_top.Controls.Add(this.btn_gmail);
            this.pnl_top.Controls.Add(this.btn_youtube);
            this.pnl_top.Controls.Add(this.btn_facebook);
            this.pnl_top.Controls.Add(this.btn_pretraga);
            this.pnl_top.Controls.Add(this.pictureBox1);
            this.pnl_top.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_top.Location = new System.Drawing.Point(0, 0);
            this.pnl_top.Name = "pnl_top";
            this.pnl_top.Size = new System.Drawing.Size(755, 51);
            this.pnl_top.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Freestyle Script", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.label6.Location = new System.Drawing.Point(53, 10);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(116, 32);
            this.label6.TabIndex = 10;
            this.label6.Text = "Igraonica Zabac";
            // 
            // btn_odjava
            // 
            this.btn_odjava.BackColor = System.Drawing.Color.Transparent;
            this.btn_odjava.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_odjava.BackgroundImage")));
            this.btn_odjava.ButtonText = "Odjava";
            this.btn_odjava.ButtonTextMarginLeft = 0;
            this.btn_odjava.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.btn_odjava.DisabledFillColor = System.Drawing.Color.Gray;
            this.btn_odjava.DisabledForecolor = System.Drawing.Color.White;
            this.btn_odjava.ForeColor = System.Drawing.Color.White;
            this.btn_odjava.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btn_odjava.IconPadding = 10;
            this.btn_odjava.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btn_odjava.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.btn_odjava.IdleBorderRadius = 20;
            this.btn_odjava.IdleBorderThickness = 0;
            this.btn_odjava.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.btn_odjava.IdleIconLeftImage = null;
            this.btn_odjava.IdleIconRightImage = null;
            this.btn_odjava.Location = new System.Drawing.Point(682, 9);
            this.btn_odjava.Name = "btn_odjava";
            stateProperties8.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties8.BorderRadius = 20;
            stateProperties8.BorderThickness = 1;
            stateProperties8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(203)))), ((int)(((byte)(219)))));
            stateProperties8.IconLeftImage = null;
            stateProperties8.IconRightImage = null;
            this.btn_odjava.onHoverState = stateProperties8;
            this.btn_odjava.Size = new System.Drawing.Size(61, 24);
            this.btn_odjava.TabIndex = 9;
            this.btn_odjava.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_odjava.Click += new System.EventHandler(this.btn_odjava_Click);
            // 
            // btn_gmail
            // 
            this.btn_gmail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.btn_gmail.Image = ((System.Drawing.Image)(resources.GetObject("btn_gmail.Image")));
            this.btn_gmail.ImageActive = null;
            this.btn_gmail.Location = new System.Drawing.Point(630, 9);
            this.btn_gmail.Name = "btn_gmail";
            this.btn_gmail.Size = new System.Drawing.Size(22, 24);
            this.btn_gmail.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btn_gmail.TabIndex = 3;
            this.btn_gmail.TabStop = false;
            this.btn_gmail.Zoom = 10;
            // 
            // btn_youtube
            // 
            this.btn_youtube.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.btn_youtube.Image = global::Forme.Properties.Resources.whiteYou;
            this.btn_youtube.ImageActive = null;
            this.btn_youtube.Location = new System.Drawing.Point(603, 9);
            this.btn_youtube.Name = "btn_youtube";
            this.btn_youtube.Size = new System.Drawing.Size(21, 24);
            this.btn_youtube.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btn_youtube.TabIndex = 8;
            this.btn_youtube.TabStop = false;
            this.btn_youtube.Zoom = 10;
            // 
            // btn_facebook
            // 
            this.btn_facebook.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.btn_facebook.Image = ((System.Drawing.Image)(resources.GetObject("btn_facebook.Image")));
            this.btn_facebook.ImageActive = null;
            this.btn_facebook.Location = new System.Drawing.Point(575, 9);
            this.btn_facebook.Name = "btn_facebook";
            this.btn_facebook.Size = new System.Drawing.Size(22, 24);
            this.btn_facebook.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btn_facebook.TabIndex = 7;
            this.btn_facebook.TabStop = false;
            this.btn_facebook.Zoom = 10;
            // 
            // btn_pretraga
            // 
            this.btn_pretraga.AcceptsReturn = false;
            this.btn_pretraga.AcceptsTab = false;
            this.btn_pretraga.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.btn_pretraga.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.btn_pretraga.BackColor = System.Drawing.Color.Transparent;
            this.btn_pretraga.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_pretraga.BackgroundImage")));
            this.btn_pretraga.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(45)))), ((int)(((byte)(145)))));
            this.btn_pretraga.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.btn_pretraga.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.btn_pretraga.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(107)))));
            this.btn_pretraga.BorderRadius = 20;
            this.btn_pretraga.BorderThickness = 2;
            this.btn_pretraga.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.btn_pretraga.DefaultFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_pretraga.DefaultText = "";
            this.btn_pretraga.FillColor = System.Drawing.Color.White;
            this.btn_pretraga.HideSelection = true;
            this.btn_pretraga.IconLeft = null;
            this.btn_pretraga.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btn_pretraga.IconPadding = 8;
            this.btn_pretraga.IconRight = global::Forme.Properties.Resources.iconPretrada;
            this.btn_pretraga.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btn_pretraga.Location = new System.Drawing.Point(267, 7);
            this.btn_pretraga.MaxLength = 32767;
            this.btn_pretraga.MinimumSize = new System.Drawing.Size(100, 35);
            this.btn_pretraga.Modified = false;
            this.btn_pretraga.Name = "btn_pretraga";
            this.btn_pretraga.PasswordChar = '\0';
            this.btn_pretraga.ReadOnly = false;
            this.btn_pretraga.SelectedText = "";
            this.btn_pretraga.SelectionLength = 0;
            this.btn_pretraga.SelectionStart = 0;
            this.btn_pretraga.ShortcutsEnabled = true;
            this.btn_pretraga.Size = new System.Drawing.Size(233, 35);
            this.btn_pretraga.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.btn_pretraga.TabIndex = 3;
            this.btn_pretraga.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_pretraga.TextMarginLeft = 5;
            this.btn_pretraga.TextPlaceholder = "Pretraga";
            this.btn_pretraga.UseSystemPasswordChar = false;
            this.btn_pretraga.TextChange += new System.EventHandler(this.btn_pretraga_TextChange);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Forme.Properties.Resources.LogoFrmGl;
            this.pictureBox1.Location = new System.Drawing.Point(3, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(44, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.panel1.Controls.Add(this.lbl_zaposleniIme);
            this.panel1.Controls.Add(this.pcb_slikaZaposlenog);
            this.panel1.Controls.Add(this.btn_proizvodi);
            this.panel1.Controls.Add(this.btn_narudzbenica);
            this.panel1.Controls.Add(this.btn_clanovi);
            this.panel1.Controls.Add(this.pnl_selektovanoDugme);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 51);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(160, 330);
            this.panel1.TabIndex = 1;
            // 
            // lbl_zaposleniIme
            // 
            this.lbl_zaposleniIme.AutoSize = true;
            this.lbl_zaposleniIme.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_zaposleniIme.ForeColor = System.Drawing.Color.White;
            this.lbl_zaposleniIme.Location = new System.Drawing.Point(28, 76);
            this.lbl_zaposleniIme.Name = "lbl_zaposleniIme";
            this.lbl_zaposleniIme.Size = new System.Drawing.Size(104, 16);
            this.lbl_zaposleniIme.TabIndex = 7;
            this.lbl_zaposleniIme.Text = "Ime zaposlenog";
            // 
            // pcb_slikaZaposlenog
            // 
            this.pcb_slikaZaposlenog.AllowFocused = false;
            this.pcb_slikaZaposlenog.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pcb_slikaZaposlenog.BorderRadius = 29;
            this.pcb_slikaZaposlenog.Image = global::Forme.Properties.Resources.userWhite;
            this.pcb_slikaZaposlenog.IsCircle = true;
            this.pcb_slikaZaposlenog.Location = new System.Drawing.Point(44, 10);
            this.pcb_slikaZaposlenog.Name = "pcb_slikaZaposlenog";
            this.pcb_slikaZaposlenog.Size = new System.Drawing.Size(58, 58);
            this.pcb_slikaZaposlenog.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pcb_slikaZaposlenog.TabIndex = 6;
            this.pcb_slikaZaposlenog.TabStop = false;
            this.pcb_slikaZaposlenog.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Square;
            // 
            // btn_proizvodi
            // 
            this.btn_proizvodi.BackColor = System.Drawing.Color.Transparent;
            this.btn_proizvodi.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_proizvodi.BackgroundImage")));
            this.btn_proizvodi.ButtonText = "Proizvodi";
            this.btn_proizvodi.ButtonTextMarginLeft = -50;
            this.btn_proizvodi.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.btn_proizvodi.DisabledFillColor = System.Drawing.Color.Gray;
            this.btn_proizvodi.DisabledForecolor = System.Drawing.Color.White;
            this.btn_proizvodi.ForeColor = System.Drawing.Color.White;
            this.btn_proizvodi.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btn_proizvodi.IconPadding = 5;
            this.btn_proizvodi.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btn_proizvodi.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.btn_proizvodi.IdleBorderRadius = 1;
            this.btn_proizvodi.IdleBorderThickness = 0;
            this.btn_proizvodi.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.btn_proizvodi.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("btn_proizvodi.IdleIconLeftImage")));
            this.btn_proizvodi.IdleIconRightImage = null;
            this.btn_proizvodi.Location = new System.Drawing.Point(3, 185);
            this.btn_proizvodi.Name = "btn_proizvodi";
            stateProperties9.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties9.BorderRadius = 1;
            stateProperties9.BorderThickness = 1;
            stateProperties9.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            stateProperties9.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("stateProperties9.IconLeftImage")));
            stateProperties9.IconRightImage = null;
            this.btn_proizvodi.onHoverState = stateProperties9;
            this.btn_proizvodi.Size = new System.Drawing.Size(154, 32);
            this.btn_proizvodi.TabIndex = 5;
            this.btn_proizvodi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_proizvodi.Click += new System.EventHandler(this.btn_proizvodi_Click);
            // 
            // btn_narudzbenica
            // 
            this.btn_narudzbenica.BackColor = System.Drawing.Color.Transparent;
            this.btn_narudzbenica.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_narudzbenica.BackgroundImage")));
            this.btn_narudzbenica.ButtonText = "Narudzbenica";
            this.btn_narudzbenica.ButtonTextMarginLeft = -20;
            this.btn_narudzbenica.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.btn_narudzbenica.DisabledFillColor = System.Drawing.Color.Gray;
            this.btn_narudzbenica.DisabledForecolor = System.Drawing.Color.White;
            this.btn_narudzbenica.ForeColor = System.Drawing.Color.White;
            this.btn_narudzbenica.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btn_narudzbenica.IconPadding = 5;
            this.btn_narudzbenica.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btn_narudzbenica.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.btn_narudzbenica.IdleBorderRadius = 1;
            this.btn_narudzbenica.IdleBorderThickness = 0;
            this.btn_narudzbenica.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.btn_narudzbenica.IdleIconLeftImage = global::Forme.Properties.Resources.NotesIcon11;
            this.btn_narudzbenica.IdleIconRightImage = null;
            this.btn_narudzbenica.Location = new System.Drawing.Point(3, 147);
            this.btn_narudzbenica.Name = "btn_narudzbenica";
            stateProperties10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties10.BorderRadius = 1;
            stateProperties10.BorderThickness = 1;
            stateProperties10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            stateProperties10.IconLeftImage = global::Forme.Properties.Resources.NotesIcon11;
            stateProperties10.IconRightImage = null;
            this.btn_narudzbenica.onHoverState = stateProperties10;
            this.btn_narudzbenica.Size = new System.Drawing.Size(154, 32);
            this.btn_narudzbenica.TabIndex = 4;
            this.btn_narudzbenica.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_narudzbenica.Click += new System.EventHandler(this.btn_narudzbenica_Click);
            // 
            // btn_clanovi
            // 
            this.btn_clanovi.BackColor = System.Drawing.Color.Transparent;
            this.btn_clanovi.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_clanovi.BackgroundImage")));
            this.btn_clanovi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_clanovi.ButtonText = "Nalog";
            this.btn_clanovi.ButtonTextMarginLeft = -71;
            this.btn_clanovi.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.btn_clanovi.DisabledFillColor = System.Drawing.SystemColors.HighlightText;
            this.btn_clanovi.DisabledForecolor = System.Drawing.Color.White;
            this.btn_clanovi.ForeColor = System.Drawing.Color.White;
            this.btn_clanovi.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btn_clanovi.IconPadding = 5;
            this.btn_clanovi.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btn_clanovi.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.btn_clanovi.IdleBorderRadius = 1;
            this.btn_clanovi.IdleBorderThickness = 0;
            this.btn_clanovi.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.btn_clanovi.IdleIconLeftImage = global::Forme.Properties.Resources.userWhite1;
            this.btn_clanovi.IdleIconRightImage = null;
            this.btn_clanovi.Location = new System.Drawing.Point(3, 109);
            this.btn_clanovi.Name = "btn_clanovi";
            stateProperties11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties11.BorderRadius = 1;
            stateProperties11.BorderThickness = 1;
            stateProperties11.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            stateProperties11.IconLeftImage = global::Forme.Properties.Resources.userWhite1;
            stateProperties11.IconRightImage = null;
            this.btn_clanovi.onHoverState = stateProperties11;
            this.btn_clanovi.Size = new System.Drawing.Size(154, 32);
            this.btn_clanovi.TabIndex = 3;
            this.btn_clanovi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_clanovi.Click += new System.EventHandler(this.btn_clanovi_Click);
            // 
            // pnl_selektovanoDugme
            // 
            this.pnl_selektovanoDugme.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.pnl_selektovanoDugme.Location = new System.Drawing.Point(0, 109);
            this.pnl_selektovanoDugme.Name = "pnl_selektovanoDugme";
            this.pnl_selektovanoDugme.Size = new System.Drawing.Size(5, 32);
            this.pnl_selektovanoDugme.TabIndex = 2;
            // 
            // pnl_left
            // 
            this.pnl_left.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.pnl_left.Controls.Add(this.lbl_selektovaniNaziv);
            this.pnl_left.Controls.Add(this.btn_Obrisi);
            this.pnl_left.Controls.Add(this.btn_kreiraj);
            this.pnl_left.Controls.Add(this.btn_promeni);
            this.pnl_left.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnl_left.Location = new System.Drawing.Point(619, 51);
            this.pnl_left.Name = "pnl_left";
            this.pnl_left.Size = new System.Drawing.Size(136, 330);
            this.pnl_left.TabIndex = 2;
            // 
            // lbl_selektovaniNaziv
            // 
            this.lbl_selektovaniNaziv.AutoSize = true;
            this.lbl_selektovaniNaziv.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_selektovaniNaziv.ForeColor = System.Drawing.Color.White;
            this.lbl_selektovaniNaziv.Location = new System.Drawing.Point(20, 52);
            this.lbl_selektovaniNaziv.Name = "lbl_selektovaniNaziv";
            this.lbl_selektovaniNaziv.Size = new System.Drawing.Size(0, 16);
            this.lbl_selektovaniNaziv.TabIndex = 3;
            this.lbl_selektovaniNaziv.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_Obrisi
            // 
            this.btn_Obrisi.BackColor = System.Drawing.Color.Transparent;
            this.btn_Obrisi.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Obrisi.BackgroundImage")));
            this.btn_Obrisi.ButtonText = "Obriši";
            this.btn_Obrisi.ButtonTextMarginLeft = 0;
            this.btn_Obrisi.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.btn_Obrisi.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.btn_Obrisi.DisabledForecolor = System.Drawing.Color.White;
            this.btn_Obrisi.ForeColor = System.Drawing.Color.White;
            this.btn_Obrisi.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btn_Obrisi.IconPadding = 10;
            this.btn_Obrisi.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btn_Obrisi.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.btn_Obrisi.IdleBorderRadius = 20;
            this.btn_Obrisi.IdleBorderThickness = 0;
            this.btn_Obrisi.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.btn_Obrisi.IdleIconLeftImage = null;
            this.btn_Obrisi.IdleIconRightImage = null;
            this.btn_Obrisi.Location = new System.Drawing.Point(5, 201);
            this.btn_Obrisi.Name = "btn_Obrisi";
            stateProperties12.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties12.BorderRadius = 20;
            stateProperties12.BorderThickness = 1;
            stateProperties12.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(203)))), ((int)(((byte)(219)))));
            stateProperties12.IconLeftImage = null;
            stateProperties12.IconRightImage = null;
            this.btn_Obrisi.onHoverState = stateProperties12;
            this.btn_Obrisi.Size = new System.Drawing.Size(126, 36);
            this.btn_Obrisi.TabIndex = 2;
            this.btn_Obrisi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Obrisi.Click += new System.EventHandler(this.btn_Obrisi_Click);
            // 
            // btn_kreiraj
            // 
            this.btn_kreiraj.BackColor = System.Drawing.Color.Transparent;
            this.btn_kreiraj.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_kreiraj.BackgroundImage")));
            this.btn_kreiraj.ButtonText = "Kreiraj";
            this.btn_kreiraj.ButtonTextMarginLeft = 0;
            this.btn_kreiraj.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.btn_kreiraj.DisabledFillColor = System.Drawing.Color.Gray;
            this.btn_kreiraj.DisabledForecolor = System.Drawing.Color.White;
            this.btn_kreiraj.ForeColor = System.Drawing.Color.White;
            this.btn_kreiraj.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btn_kreiraj.IconPadding = 10;
            this.btn_kreiraj.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btn_kreiraj.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.btn_kreiraj.IdleBorderRadius = 20;
            this.btn_kreiraj.IdleBorderThickness = 0;
            this.btn_kreiraj.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.btn_kreiraj.IdleIconLeftImage = null;
            this.btn_kreiraj.IdleIconRightImage = null;
            this.btn_kreiraj.Location = new System.Drawing.Point(5, 92);
            this.btn_kreiraj.Name = "btn_kreiraj";
            stateProperties13.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties13.BorderRadius = 20;
            stateProperties13.BorderThickness = 1;
            stateProperties13.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(203)))), ((int)(((byte)(219)))));
            stateProperties13.IconLeftImage = null;
            stateProperties13.IconRightImage = null;
            this.btn_kreiraj.onHoverState = stateProperties13;
            this.btn_kreiraj.Size = new System.Drawing.Size(126, 36);
            this.btn_kreiraj.TabIndex = 0;
            this.btn_kreiraj.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_kreiraj.Click += new System.EventHandler(this.btn_kreiraj_Click);
            // 
            // btn_promeni
            // 
            this.btn_promeni.BackColor = System.Drawing.Color.Transparent;
            this.btn_promeni.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_promeni.BackgroundImage")));
            this.btn_promeni.ButtonText = "Promeni";
            this.btn_promeni.ButtonTextMarginLeft = 0;
            this.btn_promeni.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.btn_promeni.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.btn_promeni.DisabledForecolor = System.Drawing.Color.White;
            this.btn_promeni.ForeColor = System.Drawing.Color.White;
            this.btn_promeni.IconLeftCursor = System.Windows.Forms.Cursors.Arrow;
            this.btn_promeni.IconPadding = 10;
            this.btn_promeni.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btn_promeni.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.btn_promeni.IdleBorderRadius = 20;
            this.btn_promeni.IdleBorderThickness = 0;
            this.btn_promeni.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.btn_promeni.IdleIconLeftImage = null;
            this.btn_promeni.IdleIconRightImage = null;
            this.btn_promeni.Location = new System.Drawing.Point(5, 145);
            this.btn_promeni.Name = "btn_promeni";
            stateProperties14.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties14.BorderRadius = 20;
            stateProperties14.BorderThickness = 1;
            stateProperties14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(203)))), ((int)(((byte)(219)))));
            stateProperties14.IconLeftImage = null;
            stateProperties14.IconRightImage = null;
            this.btn_promeni.onHoverState = stateProperties14;
            this.btn_promeni.Size = new System.Drawing.Size(126, 36);
            this.btn_promeni.TabIndex = 1;
            this.btn_promeni.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_promeni.Click += new System.EventHandler(this.btn_promeni_Click);
            // 
            // dgv_podaci
            // 
            this.dgv_podaci.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_podaci.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_podaci.Location = new System.Drawing.Point(166, 103);
            this.dgv_podaci.Name = "dgv_podaci";
            this.dgv_podaci.Size = new System.Drawing.Size(447, 255);
            this.dgv_podaci.TabIndex = 3;
            this.dgv_podaci.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_podaci_CellClick_1);
            // 
            // pnl_prikazElemenata
            // 
            this.pnl_prikazElemenata.Controls.Add(this.lbl_clanskiBrojIzabranogClana);
            this.pnl_prikazElemenata.Controls.Add(this.btn_ponistiPromene);
            this.pnl_prikazElemenata.Controls.Add(this.txt_adresaIzabranogClana);
            this.pnl_prikazElemenata.Controls.Add(this.txt_emailIzbranogClana);
            this.pnl_prikazElemenata.Controls.Add(this.txt_telefonIzabranogClana);
            this.pnl_prikazElemenata.Controls.Add(this.txt_prezimeIzabranogClana);
            this.pnl_prikazElemenata.Controls.Add(this.txt_imeIzabranogClana);
            this.pnl_prikazElemenata.Controls.Add(this.panel6);
            this.pnl_prikazElemenata.Controls.Add(this.panel5);
            this.pnl_prikazElemenata.Controls.Add(this.panel4);
            this.pnl_prikazElemenata.Controls.Add(this.panel3);
            this.pnl_prikazElemenata.Controls.Add(this.panel2);
            this.pnl_prikazElemenata.Controls.Add(this.label5);
            this.pnl_prikazElemenata.Controls.Add(this.label4);
            this.pnl_prikazElemenata.Controls.Add(this.label3);
            this.pnl_prikazElemenata.Controls.Add(this.label2);
            this.pnl_prikazElemenata.Controls.Add(this.label1);
            this.pnl_prikazElemenata.Location = new System.Drawing.Point(166, 61);
            this.pnl_prikazElemenata.Name = "pnl_prikazElemenata";
            this.pnl_prikazElemenata.Size = new System.Drawing.Size(20, 17);
            this.pnl_prikazElemenata.TabIndex = 4;
            // 
            // lbl_clanskiBrojIzabranogClana
            // 
            this.lbl_clanskiBrojIzabranogClana.AutoSize = true;
            this.lbl_clanskiBrojIzabranogClana.Location = new System.Drawing.Point(101, 4);
            this.lbl_clanskiBrojIzabranogClana.Name = "lbl_clanskiBrojIzabranogClana";
            this.lbl_clanskiBrojIzabranogClana.Size = new System.Drawing.Size(35, 13);
            this.lbl_clanskiBrojIzabranogClana.TabIndex = 16;
            this.lbl_clanskiBrojIzabranogClana.Text = "label6";
            this.lbl_clanskiBrojIzabranogClana.Visible = false;
            // 
            // btn_ponistiPromene
            // 
            this.btn_ponistiPromene.ActiveBorderThickness = 1;
            this.btn_ponistiPromene.ActiveCornerRadius = 20;
            this.btn_ponistiPromene.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(203)))), ((int)(((byte)(219)))));
            this.btn_ponistiPromene.ActiveForecolor = System.Drawing.Color.White;
            this.btn_ponistiPromene.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.btn_ponistiPromene.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.btn_ponistiPromene.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_ponistiPromene.BackgroundImage")));
            this.btn_ponistiPromene.ButtonText = "Poništi";
            this.btn_ponistiPromene.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_ponistiPromene.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ponistiPromene.ForeColor = System.Drawing.Color.SeaGreen;
            this.btn_ponistiPromene.IdleBorderThickness = 1;
            this.btn_ponistiPromene.IdleCornerRadius = 20;
            this.btn_ponistiPromene.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.btn_ponistiPromene.IdleForecolor = System.Drawing.Color.White;
            this.btn_ponistiPromene.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.btn_ponistiPromene.Location = new System.Drawing.Point(164, 237);
            this.btn_ponistiPromene.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_ponistiPromene.Name = "btn_ponistiPromene";
            this.btn_ponistiPromene.Size = new System.Drawing.Size(127, 46);
            this.btn_ponistiPromene.TabIndex = 15;
            this.btn_ponistiPromene.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_ponistiPromene.Click += new System.EventHandler(this.btn_ponistiPromene_Click);
            // 
            // txt_adresaIzabranogClana
            // 
            this.txt_adresaIzabranogClana.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txt_adresaIzabranogClana.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_adresaIzabranogClana.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_adresaIzabranogClana.ForeColor = System.Drawing.Color.White;
            this.txt_adresaIzabranogClana.Location = new System.Drawing.Point(175, 196);
            this.txt_adresaIzabranogClana.Name = "txt_adresaIzabranogClana";
            this.txt_adresaIzabranogClana.Size = new System.Drawing.Size(176, 18);
            this.txt_adresaIzabranogClana.TabIndex = 13;
            // 
            // txt_emailIzbranogClana
            // 
            this.txt_emailIzbranogClana.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txt_emailIzbranogClana.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_emailIzbranogClana.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_emailIzbranogClana.ForeColor = System.Drawing.Color.White;
            this.txt_emailIzbranogClana.Location = new System.Drawing.Point(164, 156);
            this.txt_emailIzbranogClana.Name = "txt_emailIzbranogClana";
            this.txt_emailIzbranogClana.Size = new System.Drawing.Size(187, 18);
            this.txt_emailIzbranogClana.TabIndex = 12;
            // 
            // txt_telefonIzabranogClana
            // 
            this.txt_telefonIzabranogClana.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txt_telefonIzabranogClana.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_telefonIzabranogClana.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_telefonIzabranogClana.ForeColor = System.Drawing.Color.White;
            this.txt_telefonIzabranogClana.Location = new System.Drawing.Point(173, 119);
            this.txt_telefonIzabranogClana.Name = "txt_telefonIzabranogClana";
            this.txt_telefonIzabranogClana.Size = new System.Drawing.Size(178, 18);
            this.txt_telefonIzabranogClana.TabIndex = 11;
            // 
            // txt_prezimeIzabranogClana
            // 
            this.txt_prezimeIzabranogClana.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txt_prezimeIzabranogClana.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_prezimeIzabranogClana.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_prezimeIzabranogClana.ForeColor = System.Drawing.Color.White;
            this.txt_prezimeIzabranogClana.Location = new System.Drawing.Point(182, 80);
            this.txt_prezimeIzabranogClana.Name = "txt_prezimeIzabranogClana";
            this.txt_prezimeIzabranogClana.Size = new System.Drawing.Size(169, 18);
            this.txt_prezimeIzabranogClana.TabIndex = 10;
            // 
            // txt_imeIzabranogClana
            // 
            this.txt_imeIzabranogClana.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txt_imeIzabranogClana.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_imeIzabranogClana.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_imeIzabranogClana.ForeColor = System.Drawing.Color.White;
            this.txt_imeIzabranogClana.Location = new System.Drawing.Point(149, 41);
            this.txt_imeIzabranogClana.Name = "txt_imeIzabranogClana";
            this.txt_imeIzabranogClana.Size = new System.Drawing.Size(202, 18);
            this.txt_imeIzabranogClana.TabIndex = 9;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.Location = new System.Drawing.Point(101, 216);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(250, 1);
            this.panel6.TabIndex = 8;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Location = new System.Drawing.Point(101, 177);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(250, 1);
            this.panel5.TabIndex = 8;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Location = new System.Drawing.Point(101, 139);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(250, 1);
            this.panel4.TabIndex = 7;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Location = new System.Drawing.Point(101, 101);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(250, 1);
            this.panel3.TabIndex = 6;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(101, 61);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(250, 1);
            this.panel2.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(98, 195);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 18);
            this.label5.TabIndex = 4;
            this.label5.Text = "Adresa : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(98, 156);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 18);
            this.label4.TabIndex = 3;
            this.label4.Text = "Email : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(98, 118);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 18);
            this.label3.TabIndex = 2;
            this.label3.Text = "Telefon : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(98, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "Prezime : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(98, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ime : ";
            // 
            // pnl_izabraniGamingProizvod
            // 
            this.pnl_izabraniGamingProizvod.AutoScroll = true;
            this.pnl_izabraniGamingProizvod.AutoScrollMinSize = new System.Drawing.Size(0, 270);
            this.pnl_izabraniGamingProizvod.Controls.Add(this.lbl_proizvodjacID);
            this.pnl_izabraniGamingProizvod.Controls.Add(this.lbl_ProizvodID);
            this.pnl_izabraniGamingProizvod.Controls.Add(this.lbl_nazivProizvodjacaIzbProizvoda);
            this.pnl_izabraniGamingProizvod.Controls.Add(this.btn_nazadProizvod);
            this.pnl_izabraniGamingProizvod.Controls.Add(this.pnl_plusUMinusProizvodjac);
            this.pnl_izabraniGamingProizvod.Controls.Add(this.pnl_plusUMinusKarakteristike);
            this.pnl_izabraniGamingProizvod.Controls.Add(this.txt_karakteristikeIzabranogGamingProizvoda);
            this.pnl_izabraniGamingProizvod.Controls.Add(this.label15);
            this.pnl_izabraniGamingProizvod.Controls.Add(this.txt_kolicinaIzabranogGamingProizvoda);
            this.pnl_izabraniGamingProizvod.Controls.Add(this.panel10);
            this.pnl_izabraniGamingProizvod.Controls.Add(this.label13);
            this.pnl_izabraniGamingProizvod.Controls.Add(this.txt_cenaIzabranogGamingProizvoda);
            this.pnl_izabraniGamingProizvod.Controls.Add(this.panel7);
            this.pnl_izabraniGamingProizvod.Controls.Add(this.label14);
            this.pnl_izabraniGamingProizvod.Controls.Add(this.pnl_podaciIzabranogProizvodjaca);
            this.pnl_izabraniGamingProizvod.Controls.Add(this.lbl_modelGProizvoda);
            this.pnl_izabraniGamingProizvod.Controls.Add(this.panel9);
            this.pnl_izabraniGamingProizvod.Controls.Add(this.label9);
            this.pnl_izabraniGamingProizvod.Controls.Add(this.lbl_proizvodjacIzbProizvda);
            this.pnl_izabraniGamingProizvod.Controls.Add(this.lbl_nazivGProizvoda);
            this.pnl_izabraniGamingProizvod.Controls.Add(this.panel8);
            this.pnl_izabraniGamingProizvod.Controls.Add(this.label7);
            this.pnl_izabraniGamingProizvod.Location = new System.Drawing.Point(166, 103);
            this.pnl_izabraniGamingProizvod.Name = "pnl_izabraniGamingProizvod";
            this.pnl_izabraniGamingProizvod.Size = new System.Drawing.Size(447, 255);
            this.pnl_izabraniGamingProizvod.TabIndex = 5;
            this.pnl_izabraniGamingProizvod.Visible = false;
            // 
            // lbl_ProizvodID
            // 
            this.lbl_ProizvodID.AutoSize = true;
            this.lbl_ProizvodID.Location = new System.Drawing.Point(347, 58);
            this.lbl_ProizvodID.Name = "lbl_ProizvodID";
            this.lbl_ProizvodID.Size = new System.Drawing.Size(35, 13);
            this.lbl_ProizvodID.TabIndex = 21;
            this.lbl_ProizvodID.Text = "label8";
            this.lbl_ProizvodID.Visible = false;
            // 
            // lbl_nazivProizvodjacaIzbProizvoda
            // 
            this.lbl_nazivProizvodjacaIzbProizvoda.AutoSize = true;
            this.lbl_nazivProizvodjacaIzbProizvoda.ForeColor = System.Drawing.Color.White;
            this.lbl_nazivProizvodjacaIzbProizvoda.Location = new System.Drawing.Point(132, 245);
            this.lbl_nazivProizvodjacaIzbProizvoda.Name = "lbl_nazivProizvodjacaIzbProizvoda";
            this.lbl_nazivProizvodjacaIzbProizvoda.Size = new System.Drawing.Size(35, 13);
            this.lbl_nazivProizvodjacaIzbProizvoda.TabIndex = 20;
            this.lbl_nazivProizvodjacaIzbProizvoda.Text = "label8";
            // 
            // btn_nazadProizvod
            // 
            this.btn_nazadProizvod.ActiveBorderThickness = 1;
            this.btn_nazadProizvod.ActiveCornerRadius = 20;
            this.btn_nazadProizvod.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(203)))), ((int)(((byte)(219)))));
            this.btn_nazadProizvod.ActiveForecolor = System.Drawing.Color.White;
            this.btn_nazadProizvod.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.btn_nazadProizvod.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.btn_nazadProizvod.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_nazadProizvod.BackgroundImage")));
            this.btn_nazadProizvod.ButtonText = "Poništi";
            this.btn_nazadProizvod.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_nazadProizvod.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_nazadProizvod.ForeColor = System.Drawing.Color.SeaGreen;
            this.btn_nazadProizvod.IdleBorderThickness = 1;
            this.btn_nazadProizvod.IdleCornerRadius = 20;
            this.btn_nazadProizvod.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.btn_nazadProizvod.IdleForecolor = System.Drawing.Color.White;
            this.btn_nazadProizvod.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.btn_nazadProizvod.Location = new System.Drawing.Point(329, 6);
            this.btn_nazadProizvod.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_nazadProizvod.Name = "btn_nazadProizvod";
            this.btn_nazadProizvod.Size = new System.Drawing.Size(87, 34);
            this.btn_nazadProizvod.TabIndex = 16;
            this.btn_nazadProizvod.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_nazadProizvod.Click += new System.EventHandler(this.btn_nazadProizvod_Click);
            // 
            // pnl_plusUMinusProizvodjac
            // 
            this.pnl_plusUMinusProizvodjac.Controls.Add(this.lbl_minusUPlusProiz);
            this.pnl_plusUMinusProizvodjac.Location = new System.Drawing.Point(16, 240);
            this.pnl_plusUMinusProizvodjac.Name = "pnl_plusUMinusProizvodjac";
            this.pnl_plusUMinusProizvodjac.Size = new System.Drawing.Size(29, 28);
            this.pnl_plusUMinusProizvodjac.TabIndex = 19;
            // 
            // lbl_minusUPlusProiz
            // 
            this.lbl_minusUPlusProiz.AutoSize = true;
            this.lbl_minusUPlusProiz.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_minusUPlusProiz.ForeColor = System.Drawing.Color.White;
            this.lbl_minusUPlusProiz.Location = new System.Drawing.Point(8, 3);
            this.lbl_minusUPlusProiz.Name = "lbl_minusUPlusProiz";
            this.lbl_minusUPlusProiz.Size = new System.Drawing.Size(18, 20);
            this.lbl_minusUPlusProiz.TabIndex = 0;
            this.lbl_minusUPlusProiz.Text = "+";
            this.lbl_minusUPlusProiz.Click += new System.EventHandler(this.lbl_minusUPlusProiz_Click);
            // 
            // pnl_plusUMinusKarakteristike
            // 
            this.pnl_plusUMinusKarakteristike.Controls.Add(this.lbl_plusMinusKar);
            this.pnl_plusUMinusKarakteristike.Location = new System.Drawing.Point(16, 198);
            this.pnl_plusUMinusKarakteristike.Name = "pnl_plusUMinusKarakteristike";
            this.pnl_plusUMinusKarakteristike.Size = new System.Drawing.Size(29, 28);
            this.pnl_plusUMinusKarakteristike.TabIndex = 18;
            // 
            // lbl_plusMinusKar
            // 
            this.lbl_plusMinusKar.AutoSize = true;
            this.lbl_plusMinusKar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_plusMinusKar.ForeColor = System.Drawing.Color.White;
            this.lbl_plusMinusKar.Location = new System.Drawing.Point(8, 3);
            this.lbl_plusMinusKar.Name = "lbl_plusMinusKar";
            this.lbl_plusMinusKar.Size = new System.Drawing.Size(18, 20);
            this.lbl_plusMinusKar.TabIndex = 0;
            this.lbl_plusMinusKar.Text = "+";
            this.lbl_plusMinusKar.Click += new System.EventHandler(this.lbl_plusMinusKar_Click);
            // 
            // txt_karakteristikeIzabranogGamingProizvoda
            // 
            this.txt_karakteristikeIzabranogGamingProizvoda.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txt_karakteristikeIzabranogGamingProizvoda.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_karakteristikeIzabranogGamingProizvoda.ForeColor = System.Drawing.Color.White;
            this.txt_karakteristikeIzabranogGamingProizvoda.Location = new System.Drawing.Point(47, 229);
            this.txt_karakteristikeIzabranogGamingProizvoda.Multiline = true;
            this.txt_karakteristikeIzabranogGamingProizvoda.Name = "txt_karakteristikeIzabranogGamingProizvoda";
            this.txt_karakteristikeIzabranogGamingProizvoda.Size = new System.Drawing.Size(248, 46);
            this.txt_karakteristikeIzabranogGamingProizvoda.TabIndex = 17;
            this.txt_karakteristikeIzabranogGamingProizvoda.Text = "sdasda";
            this.txt_karakteristikeIzabranogGamingProizvoda.Visible = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Freestyle Script", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.label15.Location = new System.Drawing.Point(42, 198);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(106, 28);
            this.label15.TabIndex = 15;
            this.label15.Text = "Karakteristike";
            // 
            // txt_kolicinaIzabranogGamingProizvoda
            // 
            this.txt_kolicinaIzabranogGamingProizvoda.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txt_kolicinaIzabranogGamingProizvoda.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_kolicinaIzabranogGamingProizvoda.ForeColor = System.Drawing.Color.White;
            this.txt_kolicinaIzabranogGamingProizvoda.Location = new System.Drawing.Point(110, 160);
            this.txt_kolicinaIzabranogGamingProizvoda.Name = "txt_kolicinaIzabranogGamingProizvoda";
            this.txt_kolicinaIzabranogGamingProizvoda.Size = new System.Drawing.Size(187, 13);
            this.txt_kolicinaIzabranogGamingProizvoda.TabIndex = 14;
            this.txt_kolicinaIzabranogGamingProizvoda.Text = "a";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.White;
            this.panel10.ForeColor = System.Drawing.Color.White;
            this.panel10.Location = new System.Drawing.Point(47, 180);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(250, 1);
            this.panel10.TabIndex = 13;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Freestyle Script", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.label13.Location = new System.Drawing.Point(42, 152);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(77, 28);
            this.label13.TabIndex = 12;
            this.label13.Text = "Kolicina : ";
            // 
            // txt_cenaIzabranogGamingProizvoda
            // 
            this.txt_cenaIzabranogGamingProizvoda.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txt_cenaIzabranogGamingProizvoda.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_cenaIzabranogGamingProizvoda.ForeColor = System.Drawing.Color.White;
            this.txt_cenaIzabranogGamingProizvoda.Location = new System.Drawing.Point(97, 115);
            this.txt_cenaIzabranogGamingProizvoda.Name = "txt_cenaIzabranogGamingProizvoda";
            this.txt_cenaIzabranogGamingProizvoda.Size = new System.Drawing.Size(200, 13);
            this.txt_cenaIzabranogGamingProizvoda.TabIndex = 11;
            this.txt_cenaIzabranogGamingProizvoda.Text = "a";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.White;
            this.panel7.ForeColor = System.Drawing.Color.White;
            this.panel7.Location = new System.Drawing.Point(47, 135);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(250, 1);
            this.panel7.TabIndex = 10;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Freestyle Script", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.label14.Location = new System.Drawing.Point(42, 107);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(60, 28);
            this.label14.TabIndex = 9;
            this.label14.Text = "Cena : ";
            // 
            // pnl_podaciIzabranogProizvodjaca
            // 
            this.pnl_podaciIzabranogProizvodjaca.Controls.Add(this.txt_adresaIzabranogProizvodjaca);
            this.pnl_podaciIzabranogProizvodjaca.Controls.Add(this.panel12);
            this.pnl_podaciIzabranogProizvodjaca.Controls.Add(this.label12);
            this.pnl_podaciIzabranogProizvodjaca.Controls.Add(this.txt_telefonIzabranogProizvodjac);
            this.pnl_podaciIzabranogProizvodjaca.Controls.Add(this.panel11);
            this.pnl_podaciIzabranogProizvodjaca.Controls.Add(this.label11);
            this.pnl_podaciIzabranogProizvodjaca.Location = new System.Drawing.Point(47, 266);
            this.pnl_podaciIzabranogProizvodjaca.Name = "pnl_podaciIzabranogProizvodjaca";
            this.pnl_podaciIzabranogProizvodjaca.Size = new System.Drawing.Size(284, 125);
            this.pnl_podaciIzabranogProizvodjaca.TabIndex = 8;
            this.pnl_podaciIzabranogProizvodjaca.Visible = false;
            // 
            // txt_adresaIzabranogProizvodjaca
            // 
            this.txt_adresaIzabranogProizvodjaca.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txt_adresaIzabranogProizvodjaca.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_adresaIzabranogProizvodjaca.ForeColor = System.Drawing.Color.White;
            this.txt_adresaIzabranogProizvodjaca.Location = new System.Drawing.Point(80, 69);
            this.txt_adresaIzabranogProizvodjaca.Name = "txt_adresaIzabranogProizvodjaca";
            this.txt_adresaIzabranogProizvodjaca.Size = new System.Drawing.Size(157, 13);
            this.txt_adresaIzabranogProizvodjaca.TabIndex = 5;
            this.txt_adresaIzabranogProizvodjaca.Text = "a";
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.White;
            this.panel12.Location = new System.Drawing.Point(18, 90);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(220, 1);
            this.panel12.TabIndex = 4;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Freestyle Script", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.label12.Location = new System.Drawing.Point(13, 62);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(56, 25);
            this.label12.TabIndex = 3;
            this.label12.Text = "Adresa :";
            // 
            // txt_telefonIzabranogProizvodjac
            // 
            this.txt_telefonIzabranogProizvodjac.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txt_telefonIzabranogProizvodjac.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_telefonIzabranogProizvodjac.ForeColor = System.Drawing.Color.White;
            this.txt_telefonIzabranogProizvodjac.Location = new System.Drawing.Point(80, 15);
            this.txt_telefonIzabranogProizvodjac.Name = "txt_telefonIzabranogProizvodjac";
            this.txt_telefonIzabranogProizvodjac.Size = new System.Drawing.Size(157, 13);
            this.txt_telefonIzabranogProizvodjac.TabIndex = 2;
            this.txt_telefonIzabranogProizvodjac.Text = "a";
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.White;
            this.panel11.Location = new System.Drawing.Point(18, 36);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(220, 1);
            this.panel11.TabIndex = 1;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Freestyle Script", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.label11.Location = new System.Drawing.Point(13, 8);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(61, 25);
            this.label11.TabIndex = 0;
            this.label11.Text = "Telefon :";
            // 
            // lbl_modelGProizvoda
            // 
            this.lbl_modelGProizvoda.AutoSize = true;
            this.lbl_modelGProizvoda.ForeColor = System.Drawing.Color.White;
            this.lbl_modelGProizvoda.Location = new System.Drawing.Point(104, 70);
            this.lbl_modelGProizvoda.Name = "lbl_modelGProizvoda";
            this.lbl_modelGProizvoda.Size = new System.Drawing.Size(35, 13);
            this.lbl_modelGProizvoda.TabIndex = 7;
            this.lbl_modelGProizvoda.Text = "label8";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.White;
            this.panel9.ForeColor = System.Drawing.Color.White;
            this.panel9.Location = new System.Drawing.Point(47, 89);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(250, 1);
            this.panel9.TabIndex = 6;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Freestyle Script", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.label9.Location = new System.Drawing.Point(42, 61);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 28);
            this.label9.TabIndex = 5;
            this.label9.Text = "Model : ";
            // 
            // lbl_proizvodjacIzbProizvda
            // 
            this.lbl_proizvodjacIzbProizvda.AutoSize = true;
            this.lbl_proizvodjacIzbProizvda.Font = new System.Drawing.Font("Freestyle Script", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_proizvodjacIzbProizvda.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.lbl_proizvodjacIzbProizvda.Location = new System.Drawing.Point(48, 235);
            this.lbl_proizvodjacIzbProizvda.Name = "lbl_proizvodjacIzbProizvda";
            this.lbl_proizvodjacIzbProizvda.Size = new System.Drawing.Size(91, 28);
            this.lbl_proizvodjacIzbProizvda.TabIndex = 4;
            this.lbl_proizvodjacIzbProizvda.Text = "Proizvdjac : ";
            // 
            // lbl_nazivGProizvoda
            // 
            this.lbl_nazivGProizvoda.AutoSize = true;
            this.lbl_nazivGProizvoda.ForeColor = System.Drawing.Color.White;
            this.lbl_nazivGProizvoda.Location = new System.Drawing.Point(104, 20);
            this.lbl_nazivGProizvoda.Name = "lbl_nazivGProizvoda";
            this.lbl_nazivGProizvoda.Size = new System.Drawing.Size(35, 13);
            this.lbl_nazivGProizvoda.TabIndex = 2;
            this.lbl_nazivGProizvoda.Text = "label8";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.White;
            this.panel8.ForeColor = System.Drawing.Color.White;
            this.panel8.Location = new System.Drawing.Point(47, 39);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(250, 1);
            this.panel8.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Freestyle Script", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.label7.Location = new System.Drawing.Point(42, 11);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 28);
            this.label7.TabIndex = 0;
            this.label7.Text = "Naziv :";
            // 
            // lbl_proizvodjacID
            // 
            this.lbl_proizvodjacID.AutoSize = true;
            this.lbl_proizvodjacID.Location = new System.Drawing.Point(358, 245);
            this.lbl_proizvodjacID.Name = "lbl_proizvodjacID";
            this.lbl_proizvodjacID.Size = new System.Drawing.Size(35, 13);
            this.lbl_proizvodjacID.TabIndex = 22;
            this.lbl_proizvodjacID.Text = "label8";
            this.lbl_proizvodjacID.Visible = false;
            // 
            // frm_glavna
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(755, 381);
            this.Controls.Add(this.pnl_izabraniGamingProizvod);
            this.Controls.Add(this.pnl_prikazElemenata);
            this.Controls.Add(this.dgv_podaci);
            this.Controls.Add(this.pnl_left);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnl_top);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frm_glavna";
            this.Text = " ";
            this.Load += new System.EventHandler(this.FrmGlForma_Load);
            this.pnl_top.ResumeLayout(false);
            this.pnl_top.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_gmail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_youtube)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_facebook)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcb_slikaZaposlenog)).EndInit();
            this.pnl_left.ResumeLayout(false);
            this.pnl_left.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_podaci)).EndInit();
            this.pnl_prikazElemenata.ResumeLayout(false);
            this.pnl_prikazElemenata.PerformLayout();
            this.pnl_izabraniGamingProizvod.ResumeLayout(false);
            this.pnl_izabraniGamingProizvod.PerformLayout();
            this.pnl_plusUMinusProizvodjac.ResumeLayout(false);
            this.pnl_plusUMinusProizvodjac.PerformLayout();
            this.pnl_plusUMinusKarakteristike.ResumeLayout(false);
            this.pnl_plusUMinusKarakteristike.PerformLayout();
            this.pnl_podaciIzabranogProizvodjaca.ResumeLayout(false);
            this.pnl_podaciIzabranogProizvodjaca.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel pnl_top;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btn_clanovi;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btn_narudzbenica;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btn_proizvodi;
        private System.Windows.Forms.Panel pnl_left;
        
        private Bunifu.UI.WinForms.BunifuPictureBox pcb_slikaZaposlenog;
        private System.Windows.Forms.Panel pnl_selektovanoDugme;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btn_kreiraj;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btn_Obrisi;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btn_promeni;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox btn_pretraga;
        private System.Windows.Forms.Label lbl_selektovaniNaziv;
        private Bunifu.Framework.UI.BunifuImageButton btn_gmail;
        private Bunifu.Framework.UI.BunifuImageButton btn_youtube;
        private Bunifu.Framework.UI.BunifuImageButton btn_facebook;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btn_odjava;
        private System.Windows.Forms.DataGridView dgv_podaci;
        private System.Windows.Forms.Panel pnl_prikazElemenata;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_imeIzabranogClana;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txt_adresaIzabranogClana;
        private System.Windows.Forms.TextBox txt_emailIzbranogClana;
        private System.Windows.Forms.TextBox txt_telefonIzabranogClana;
        private System.Windows.Forms.TextBox txt_prezimeIzabranogClana;
        private Bunifu.Framework.UI.BunifuThinButton2 btn_ponistiPromene;
        private System.Windows.Forms.Label lbl_clanskiBrojIzabranogClana;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lbl_zaposleniIme;
        private System.Windows.Forms.Panel pnl_izabraniGamingProizvod;
        private System.Windows.Forms.Label lbl_nazivGProizvoda;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbl_proizvodjacIzbProizvda;
        private System.Windows.Forms.Label lbl_modelGProizvoda;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel pnl_podaciIzabranogProizvodjaca;
        private System.Windows.Forms.TextBox txt_adresaIzabranogProizvodjaca;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txt_telefonIzabranogProizvodjac;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txt_kolicinaIzabranogGamingProizvoda;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txt_cenaIzabranogGamingProizvoda;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txt_karakteristikeIzabranogGamingProizvoda;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel pnl_plusUMinusKarakteristike;
        private System.Windows.Forms.Label lbl_plusMinusKar;
        private System.Windows.Forms.Panel pnl_plusUMinusProizvodjac;
        private System.Windows.Forms.Label lbl_minusUPlusProiz;
        private Bunifu.Framework.UI.BunifuThinButton2 btn_nazadProizvod;
        private System.Windows.Forms.Label lbl_nazivProizvodjacaIzbProizvoda;
        private System.Windows.Forms.Label lbl_ProizvodID;
        private System.Windows.Forms.Label lbl_proizvodjacID;
    }
}