﻿namespace Forme
{
    partial class UnosProizvoda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_nazivProizvoda = new System.Windows.Forms.Label();
            this.lbl_modelProizvoda = new System.Windows.Forms.Label();
            this.lbl_cenaProizvoda = new System.Windows.Forms.Label();
            this.lbl_proizvodjacProizvoda = new System.Windows.Forms.Label();
            this.txt_naziv = new System.Windows.Forms.TextBox();
            this.txt_model = new System.Windows.Forms.TextBox();
            this.txt_cena = new System.Windows.Forms.TextBox();
            this.cbx_proizvodjac = new System.Windows.Forms.ComboBox();
            this.btn_Sacuvaj = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_nazivProizvoda
            // 
            this.lbl_nazivProizvoda.AutoSize = true;
            this.lbl_nazivProizvoda.Location = new System.Drawing.Point(27, 29);
            this.lbl_nazivProizvoda.Name = "lbl_nazivProizvoda";
            this.lbl_nazivProizvoda.Size = new System.Drawing.Size(40, 13);
            this.lbl_nazivProizvoda.TabIndex = 0;
            this.lbl_nazivProizvoda.Text = "Naziv :";
            // 
            // lbl_modelProizvoda
            // 
            this.lbl_modelProizvoda.AutoSize = true;
            this.lbl_modelProizvoda.Location = new System.Drawing.Point(30, 65);
            this.lbl_modelProizvoda.Name = "lbl_modelProizvoda";
            this.lbl_modelProizvoda.Size = new System.Drawing.Size(45, 13);
            this.lbl_modelProizvoda.TabIndex = 1;
            this.lbl_modelProizvoda.Text = "Model : ";
            // 
            // lbl_cenaProizvoda
            // 
            this.lbl_cenaProizvoda.AutoSize = true;
            this.lbl_cenaProizvoda.Location = new System.Drawing.Point(30, 100);
            this.lbl_cenaProizvoda.Name = "lbl_cenaProizvoda";
            this.lbl_cenaProizvoda.Size = new System.Drawing.Size(38, 13);
            this.lbl_cenaProizvoda.TabIndex = 2;
            this.lbl_cenaProizvoda.Text = "Cena :";
            // 
            // lbl_proizvodjacProizvoda
            // 
            this.lbl_proizvodjacProizvoda.AutoSize = true;
            this.lbl_proizvodjacProizvoda.Location = new System.Drawing.Point(30, 134);
            this.lbl_proizvodjacProizvoda.Name = "lbl_proizvodjacProizvoda";
            this.lbl_proizvodjacProizvoda.Size = new System.Drawing.Size(67, 13);
            this.lbl_proizvodjacProizvoda.TabIndex = 3;
            this.lbl_proizvodjacProizvoda.Text = "Proizvođač :";
            // 
            // txt_naziv
            // 
            this.txt_naziv.Location = new System.Drawing.Point(116, 22);
            this.txt_naziv.Name = "txt_naziv";
            this.txt_naziv.Size = new System.Drawing.Size(121, 20);
            this.txt_naziv.TabIndex = 4;
            // 
            // txt_model
            // 
            this.txt_model.Location = new System.Drawing.Point(116, 58);
            this.txt_model.Name = "txt_model";
            this.txt_model.Size = new System.Drawing.Size(121, 20);
            this.txt_model.TabIndex = 5;
            // 
            // txt_cena
            // 
            this.txt_cena.Location = new System.Drawing.Point(116, 93);
            this.txt_cena.Name = "txt_cena";
            this.txt_cena.Size = new System.Drawing.Size(121, 20);
            this.txt_cena.TabIndex = 6;
            // 
            // cbx_proizvodjac
            // 
            this.cbx_proizvodjac.FormattingEnabled = true;
            this.cbx_proizvodjac.Location = new System.Drawing.Point(116, 126);
            this.cbx_proizvodjac.Name = "cbx_proizvodjac";
            this.cbx_proizvodjac.Size = new System.Drawing.Size(121, 21);
            this.cbx_proizvodjac.TabIndex = 7;
            // 
            // btn_Sacuvaj
            // 
            this.btn_Sacuvaj.Location = new System.Drawing.Point(83, 179);
            this.btn_Sacuvaj.Name = "btn_Sacuvaj";
            this.btn_Sacuvaj.Size = new System.Drawing.Size(113, 23);
            this.btn_Sacuvaj.TabIndex = 8;
            this.btn_Sacuvaj.Text = "Sačuvaj";
            this.btn_Sacuvaj.UseVisualStyleBackColor = true;
            this.btn_Sacuvaj.Click += new System.EventHandler(this.btn_Sacuvaj_Click);
            // 
            // UnosProizvoda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 233);
            this.Controls.Add(this.btn_Sacuvaj);
            this.Controls.Add(this.cbx_proizvodjac);
            this.Controls.Add(this.txt_cena);
            this.Controls.Add(this.txt_model);
            this.Controls.Add(this.txt_naziv);
            this.Controls.Add(this.lbl_proizvodjacProizvoda);
            this.Controls.Add(this.lbl_cenaProizvoda);
            this.Controls.Add(this.lbl_modelProizvoda);
            this.Controls.Add(this.lbl_nazivProizvoda);
            this.Name = "UnosProizvoda";
            this.Text = "UnosProizvoda";
            this.Load += new System.EventHandler(this.UnosProizvoda_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_nazivProizvoda;
        private System.Windows.Forms.Label lbl_modelProizvoda;
        private System.Windows.Forms.Label lbl_cenaProizvoda;
        private System.Windows.Forms.Label lbl_proizvodjacProizvoda;
        private System.Windows.Forms.TextBox txt_naziv;
        private System.Windows.Forms.TextBox txt_model;
        private System.Windows.Forms.TextBox txt_cena;
        private System.Windows.Forms.ComboBox cbx_proizvodjac;
        private System.Windows.Forms.Button btn_Sacuvaj;
    }
}