﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forme
{
    public partial class FrmNarudzbenica : Form
    {
        public FrmNarudzbenica()
        {
            InitializeComponent();
        }

        private void FrmNarudzbenica_Load(object sender, EventArgs e)
        {

        }

        private void btn_sacuvajProizvod_Click(object sender, EventArgs e)
        {

        }
    }
}
