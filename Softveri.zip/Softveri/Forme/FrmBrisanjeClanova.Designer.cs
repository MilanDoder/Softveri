﻿namespace Forme
{
    partial class FrmBrisanjeClanova
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_pretragaClana = new System.Windows.Forms.Label();
            this.txt_pretragaClana = new System.Windows.Forms.TextBox();
            this.dgv_BrisanjeClanova = new System.Windows.Forms.DataGridView();
            this.btn_obrisiClana = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_BrisanjeClanova)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_pretragaClana
            // 
            this.lbl_pretragaClana.AutoSize = true;
            this.lbl_pretragaClana.Location = new System.Drawing.Point(13, 19);
            this.lbl_pretragaClana.Name = "lbl_pretragaClana";
            this.lbl_pretragaClana.Size = new System.Drawing.Size(47, 13);
            this.lbl_pretragaClana.TabIndex = 0;
            this.lbl_pretragaClana.Text = "Pretraga";
            // 
            // txt_pretragaClana
            // 
            this.txt_pretragaClana.Location = new System.Drawing.Point(107, 12);
            this.txt_pretragaClana.Name = "txt_pretragaClana";
            this.txt_pretragaClana.Size = new System.Drawing.Size(151, 20);
            this.txt_pretragaClana.TabIndex = 1;
            this.txt_pretragaClana.TextChanged += new System.EventHandler(this.txt_pretragaClana_TextChanged);
            // 
            // dgv_BrisanjeClanova
            // 
            this.dgv_BrisanjeClanova.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_BrisanjeClanova.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_BrisanjeClanova.Location = new System.Drawing.Point(16, 59);
            this.dgv_BrisanjeClanova.Name = "dgv_BrisanjeClanova";
            this.dgv_BrisanjeClanova.Size = new System.Drawing.Size(362, 150);
            this.dgv_BrisanjeClanova.TabIndex = 2;
            // 
            // btn_obrisiClana
            // 
            this.btn_obrisiClana.Location = new System.Drawing.Point(142, 227);
            this.btn_obrisiClana.Name = "btn_obrisiClana";
            this.btn_obrisiClana.Size = new System.Drawing.Size(99, 23);
            this.btn_obrisiClana.TabIndex = 3;
            this.btn_obrisiClana.Text = "Obriši";
            this.btn_obrisiClana.UseVisualStyleBackColor = true;
            this.btn_obrisiClana.Click += new System.EventHandler(this.btn_obrisiClana_Click);
            // 
            // FrmBrisanjeClanova
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(388, 262);
            this.Controls.Add(this.btn_obrisiClana);
            this.Controls.Add(this.dgv_BrisanjeClanova);
            this.Controls.Add(this.txt_pretragaClana);
            this.Controls.Add(this.lbl_pretragaClana);
            this.Name = "FrmBrisanjeClanova";
            this.Text = "FrmBrisanjeClanova";
            this.Load += new System.EventHandler(this.FrmBrisanjeClanova_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_BrisanjeClanova)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_pretragaClana;
        private System.Windows.Forms.TextBox txt_pretragaClana;
        private System.Windows.Forms.DataGridView dgv_BrisanjeClanova;
        private System.Windows.Forms.Button btn_obrisiClana;
    }
}