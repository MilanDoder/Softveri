﻿using System;

namespace Forme
{
    partial class GlavnaForma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.proizvodToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btn_unosProzvoda = new System.Windows.Forms.ToolStripMenuItem();
            this.brisanjeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.izmenaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.narudzbenicaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dgv_pretragaClanova = new System.Windows.Forms.DataGridView();
            this.lbl_pretraga = new System.Windows.Forms.Label();
            this.txt_pretragaClanova = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_pretragaClanova)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.proizvodToolStripMenuItem,
            this.narudzbenicaToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(527, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // proizvodToolStripMenuItem
            // 
            this.proizvodToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btn_unosProzvoda,
            this.brisanjeToolStripMenuItem,
            this.izmenaToolStripMenuItem});
            this.proizvodToolStripMenuItem.Name = "proizvodToolStripMenuItem";
            this.proizvodToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.proizvodToolStripMenuItem.Text = "Proizvod";
            // 
            // btn_unosProzvoda
            // 
            this.btn_unosProzvoda.Name = "btn_unosProzvoda";
            this.btn_unosProzvoda.Size = new System.Drawing.Size(115, 22);
            this.btn_unosProzvoda.Text = "Unos";
            // 
            // brisanjeToolStripMenuItem
            // 
            this.brisanjeToolStripMenuItem.Name = "brisanjeToolStripMenuItem";
            this.brisanjeToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.brisanjeToolStripMenuItem.Text = "Brisanje";
            // 
            // izmenaToolStripMenuItem
            // 
            this.izmenaToolStripMenuItem.Name = "izmenaToolStripMenuItem";
            this.izmenaToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.izmenaToolStripMenuItem.Text = "Izmena";
            // 
            // narudzbenicaToolStripMenuItem
            // 
            this.narudzbenicaToolStripMenuItem.Name = "narudzbenicaToolStripMenuItem";
            this.narudzbenicaToolStripMenuItem.Size = new System.Drawing.Size(92, 20);
            this.narudzbenicaToolStripMenuItem.Text = "Narudzbenica";
            // 
            // dgv_pretragaClanova
            // 
            this.dgv_pretragaClanova.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_pretragaClanova.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_pretragaClanova.Location = new System.Drawing.Point(12, 60);
            this.dgv_pretragaClanova.Name = "dgv_pretragaClanova";
            this.dgv_pretragaClanova.Size = new System.Drawing.Size(479, 202);
            this.dgv_pretragaClanova.TabIndex = 1;
            this.dgv_pretragaClanova.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_pretragaClanova_CellContentClick);
            // 
            // lbl_pretraga
            // 
            this.lbl_pretraga.AutoSize = true;
            this.lbl_pretraga.Location = new System.Drawing.Point(13, 28);
            this.lbl_pretraga.Name = "lbl_pretraga";
            this.lbl_pretraga.Size = new System.Drawing.Size(47, 13);
            this.lbl_pretraga.TabIndex = 2;
            this.lbl_pretraga.Text = "Pretraga";
            // 
            // txt_pretragaClanova
            // 
            this.txt_pretragaClanova.Location = new System.Drawing.Point(87, 28);
            this.txt_pretragaClanova.Name = "txt_pretragaClanova";
            this.txt_pretragaClanova.Size = new System.Drawing.Size(143, 20);
            this.txt_pretragaClanova.TabIndex = 3;
            this.txt_pretragaClanova.TextChanged += new System.EventHandler(this.txt_pretragaClanova_TextChanged);
            // 
            // GlavnaForma
            // 
            this.ClientSize = new System.Drawing.Size(527, 306);
            this.Controls.Add(this.txt_pretragaClanova);
            this.Controls.Add(this.lbl_pretraga);
            this.Controls.Add(this.dgv_pretragaClanova);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "GlavnaForma";
            this.Load += new System.EventHandler(this.GlavnaForma_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_pretragaClanova)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }




        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem proizvodToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem btn_unosProzvoda;
        private System.Windows.Forms.ToolStripMenuItem brisanjeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem izmenaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem narudzbenicaToolStripMenuItem;
        private System.Windows.Forms.DataGridView dgv_pretragaClanova;
        private System.Windows.Forms.Label lbl_pretraga;
        private System.Windows.Forms.TextBox txt_pretragaClanova;
    }
}