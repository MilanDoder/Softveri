﻿using Klasa;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forme
{
    public partial class GlavnaForma : Form
    {
        private BindingList<Nalog> bindingListaNaloga = new BindingList<Nalog>();

        public GlavnaForma()
        {
            InitializeComponent();
        }

        private void unosProizvodaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UnosProizvoda formaUnos = new UnosProizvoda();

            formaUnos.Show();
            this.Hide();
            this.Owner = formaUnos;
        }

        private void prikazToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void txt_pretragaClanova_TextChanged(object sender, EventArgs e)
        {
            bindingListaNaloga = new BindingList<Nalog>((BindingList<Nalog>)Kontroler.Kontroler.Instanca.PretragaNaloga(txt_pretragaClanova.Text));
            dgv_pretragaClanova.DataSource = bindingListaNaloga;
        }

        private void GlavnaForma_Load(object sender, EventArgs e)
        {
            // = new BindingList<Nalog>(Kontroler.Kontroler.Instanca.VratiSveClanove());
            dgv_pretragaClanova.DataSource = bindingListaNaloga;
        }

        private void bunifuCheckBox1_CheckedChanged(object sender, Bunifu.UI.WinForms.BunifuCheckBox.CheckedChangedEventArgs e)
        {

        }

        private void dgv_pretragaClanova_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
