﻿using System;

namespace Forme
{
    partial class UnosClana
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_imeClana = new System.Windows.Forms.Label();
            this.lvl_prezimeClana = new System.Windows.Forms.Label();
            this.lbl_kontaktTelefon = new System.Windows.Forms.Label();
            this.lbl_email = new System.Windows.Forms.Label();
            this.lbl_adresaStanovanja = new System.Windows.Forms.Label();
            this.txt_imeClana = new System.Windows.Forms.TextBox();
            this.txt_prezimeClana = new System.Windows.Forms.TextBox();
            this.txt_telefonClana = new System.Windows.Forms.TextBox();
            this.txt_emailClana = new System.Windows.Forms.TextBox();
            this.txt_AdresaStanovanja = new System.Windows.Forms.TextBox();
            this.btn_sacuvajClana = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_imeClana
            // 
            this.lbl_imeClana.AutoSize = true;
            this.lbl_imeClana.Location = new System.Drawing.Point(29, 24);
            this.lbl_imeClana.Name = "lbl_imeClana";
            this.lbl_imeClana.Size = new System.Drawing.Size(30, 13);
            this.lbl_imeClana.TabIndex = 0;
            this.lbl_imeClana.Text = "Ime :";
            // 
            // lvl_prezimeClana
            // 
            this.lvl_prezimeClana.AutoSize = true;
            this.lvl_prezimeClana.Location = new System.Drawing.Point(29, 60);
            this.lvl_prezimeClana.Name = "lvl_prezimeClana";
            this.lvl_prezimeClana.Size = new System.Drawing.Size(50, 13);
            this.lvl_prezimeClana.TabIndex = 1;
            this.lvl_prezimeClana.Text = "Prezime :";
            // 
            // lbl_kontaktTelefon
            // 
            this.lbl_kontaktTelefon.AutoSize = true;
            this.lbl_kontaktTelefon.Location = new System.Drawing.Point(32, 93);
            this.lbl_kontaktTelefon.Name = "lbl_kontaktTelefon";
            this.lbl_kontaktTelefon.Size = new System.Drawing.Size(49, 13);
            this.lbl_kontaktTelefon.TabIndex = 2;
            this.lbl_kontaktTelefon.Text = "Telefon :";
            // 
            // lbl_email
            // 
            this.lbl_email.AutoSize = true;
            this.lbl_email.Location = new System.Drawing.Point(35, 126);
            this.lbl_email.Name = "lbl_email";
            this.lbl_email.Size = new System.Drawing.Size(41, 13);
            this.lbl_email.TabIndex = 3;
            this.lbl_email.Text = "E-mail :";
            // 
            // lbl_adresaStanovanja
            // 
            this.lbl_adresaStanovanja.AutoSize = true;
            this.lbl_adresaStanovanja.Location = new System.Drawing.Point(35, 160);
            this.lbl_adresaStanovanja.Name = "lbl_adresaStanovanja";
            this.lbl_adresaStanovanja.Size = new System.Drawing.Size(46, 13);
            this.lbl_adresaStanovanja.TabIndex = 4;
            this.lbl_adresaStanovanja.Text = "Adresa :";
            // 
            // txt_imeClana
            // 
            this.txt_imeClana.Location = new System.Drawing.Point(107, 24);
            this.txt_imeClana.Name = "txt_imeClana";
            this.txt_imeClana.Size = new System.Drawing.Size(138, 20);
            this.txt_imeClana.TabIndex = 5;
            // 
            // txt_prezimeClana
            // 
            this.txt_prezimeClana.Location = new System.Drawing.Point(107, 60);
            this.txt_prezimeClana.Name = "txt_prezimeClana";
            this.txt_prezimeClana.Size = new System.Drawing.Size(138, 20);
            this.txt_prezimeClana.TabIndex = 6;
            // 
            // txt_telefonClana
            // 
            this.txt_telefonClana.Location = new System.Drawing.Point(107, 93);
            this.txt_telefonClana.Name = "txt_telefonClana";
            this.txt_telefonClana.Size = new System.Drawing.Size(138, 20);
            this.txt_telefonClana.TabIndex = 7;
            // 
            // txt_emailClana
            // 
            this.txt_emailClana.Location = new System.Drawing.Point(107, 126);
            this.txt_emailClana.Name = "txt_emailClana";
            this.txt_emailClana.Size = new System.Drawing.Size(138, 20);
            this.txt_emailClana.TabIndex = 8;
            // 
            // txt_AdresaStanovanja
            // 
            this.txt_AdresaStanovanja.Location = new System.Drawing.Point(107, 160);
            this.txt_AdresaStanovanja.Name = "txt_AdresaStanovanja";
            this.txt_AdresaStanovanja.Size = new System.Drawing.Size(138, 20);
            this.txt_AdresaStanovanja.TabIndex = 9;
            // 
            // btn_sacuvajClana
            // 
            this.btn_sacuvajClana.Location = new System.Drawing.Point(107, 204);
            this.btn_sacuvajClana.Name = "btn_sacuvajClana";
            this.btn_sacuvajClana.Size = new System.Drawing.Size(75, 23);
            this.btn_sacuvajClana.TabIndex = 10;
            this.btn_sacuvajClana.Text = "Sačuvaj";
            this.btn_sacuvajClana.UseVisualStyleBackColor = true;
            this.btn_sacuvajClana.Click += new System.EventHandler(this.btn_sacuvajClana_Click);
            // 
            // UnosClana
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.btn_sacuvajClana);
            this.Controls.Add(this.txt_AdresaStanovanja);
            this.Controls.Add(this.txt_emailClana);
            this.Controls.Add(this.txt_telefonClana);
            this.Controls.Add(this.txt_prezimeClana);
            this.Controls.Add(this.txt_imeClana);
            this.Controls.Add(this.lbl_adresaStanovanja);
            this.Controls.Add(this.lbl_email);
            this.Controls.Add(this.lbl_kontaktTelefon);
            this.Controls.Add(this.lvl_prezimeClana);
            this.Controls.Add(this.lbl_imeClana);
            this.Name = "UnosClana";
            this.Text = "UnosClana";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void btn_sacuvajClana_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private System.Windows.Forms.Label lbl_imeClana;
        private System.Windows.Forms.Label lvl_prezimeClana;
        private System.Windows.Forms.Label lbl_kontaktTelefon;
        private System.Windows.Forms.Label lbl_email;
        private System.Windows.Forms.Label lbl_adresaStanovanja;
        private System.Windows.Forms.TextBox txt_imeClana;
        private System.Windows.Forms.TextBox txt_prezimeClana;
        private System.Windows.Forms.TextBox txt_telefonClana;
        private System.Windows.Forms.TextBox txt_emailClana;
        private System.Windows.Forms.TextBox txt_AdresaStanovanja;
        private System.Windows.Forms.Button btn_sacuvajClana;
    }
}