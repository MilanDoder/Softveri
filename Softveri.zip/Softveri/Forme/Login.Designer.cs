﻿namespace Forme
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_username = new System.Windows.Forms.Label();
            this.lvl_sifra = new System.Windows.Forms.Label();
            this.txt_korsinIme = new System.Windows.Forms.TextBox();
            this.txt_sifra = new System.Windows.Forms.TextBox();
            this.btn_potvrdi = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_username
            // 
            this.lbl_username.AutoSize = true;
            this.lbl_username.Location = new System.Drawing.Point(34, 37);
            this.lbl_username.Name = "lbl_username";
            this.lbl_username.Size = new System.Drawing.Size(81, 13);
            this.lbl_username.TabIndex = 1;
            this.lbl_username.Text = "Korisničko ime :";
            // 
            // lvl_sifra
            // 
            this.lvl_sifra.AutoSize = true;
            this.lvl_sifra.Location = new System.Drawing.Point(37, 80);
            this.lvl_sifra.Name = "lvl_sifra";
            this.lvl_sifra.Size = new System.Drawing.Size(34, 13);
            this.lvl_sifra.TabIndex = 2;
            this.lvl_sifra.Text = "Šifra :";
            // 
            // txt_korsinIme
            // 
            this.txt_korsinIme.Location = new System.Drawing.Point(135, 37);
            this.txt_korsinIme.Name = "txt_korsinIme";
            this.txt_korsinIme.Size = new System.Drawing.Size(137, 20);
            this.txt_korsinIme.TabIndex = 3;
            // 
            // txt_sifra
            // 
            this.txt_sifra.Location = new System.Drawing.Point(135, 80);
            this.txt_sifra.Name = "txt_sifra";
            this.txt_sifra.PasswordChar = '*';
            this.txt_sifra.Size = new System.Drawing.Size(137, 20);
            this.txt_sifra.TabIndex = 4;
            // 
            // btn_potvrdi
            // 
            this.btn_potvrdi.Location = new System.Drawing.Point(96, 131);
            this.btn_potvrdi.Name = "btn_potvrdi";
            this.btn_potvrdi.Size = new System.Drawing.Size(96, 23);
            this.btn_potvrdi.TabIndex = 5;
            this.btn_potvrdi.Text = "Potvrdi";
            this.btn_potvrdi.UseVisualStyleBackColor = true;
            this.btn_potvrdi.Click += new System.EventHandler(this.btn_potvrdi_Click);
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 183);
            this.Controls.Add(this.btn_potvrdi);
            this.Controls.Add(this.txt_sifra);
            this.Controls.Add(this.txt_korsinIme);
            this.Controls.Add(this.lvl_sifra);
            this.Controls.Add(this.lbl_username);
            this.Name = "Login";
            this.Text = "Login";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lbl_username;
        private System.Windows.Forms.Label lvl_sifra;
        private System.Windows.Forms.TextBox txt_korsinIme;
        private System.Windows.Forms.TextBox txt_sifra;
        private System.Windows.Forms.Button btn_potvrdi;
    }
}