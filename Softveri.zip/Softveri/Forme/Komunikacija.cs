﻿using Klasa;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Net.Http;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace Forme
{
    public class Komunikacija
    {
        private static Komunikacija _instanca;
        private TcpClient klijent;
        private NetworkStream stream;
        private BinaryFormatter formater;


        public static Komunikacija Instanca{
            get{
                if (_instanca == null) {
                    _instanca = new Komunikacija();
                }
                return _instanca;
            }
        }


        private Komunikacija()
        {
            klijent = new TcpClient("127.0.0.1", 10000);
            stream = this.klijent.GetStream();
            formater = new BinaryFormatter();
        }


        internal IList<Proizvodjac> vratiProizvodjace()
        {
            Zahtev zahtev = new Zahtev
            {
                Operacija = Operacija.VratiProizvodjace
            };
            this.formater.Serialize(this.stream, zahtev);

            Odgovor odgovor = (Odgovor)this.formater.Deserialize(this.stream);

            if (odgovor.Uspesnost)
            {
                return (List<Proizvodjac>)odgovor.Podaci;
            }
            else {
                throw new Exception(odgovor.Podaci.ToString());
            }

        }
        public IList<GamingProizvod> ucitajGamingProizvode() {
            Zahtev zahtev = new Zahtev
            {
                Operacija = Operacija.VratiSveProizvode,
            };
            this.formater.Serialize(this.stream, zahtev);

            Odgovor odgovor = (Odgovor)this.formater.Deserialize(this.stream);

            if (odgovor.Uspesnost)
            {
                return (IList<GamingProizvod>)odgovor.Podaci;
            }
            else {
                throw new Exception(odgovor.Podaci.ToString());
            }

        }

        internal bool kreirajNalog(Nalog n)
        {
            Zahtev zahtev = new Zahtev
            {
                Operacija = Operacija.UbaciNalog,
                Podaci = n
            };
            this.formater.Serialize(this.stream, zahtev);


            Odgovor odgovor = (Odgovor)this.formater.Deserialize(this.stream);

            if (odgovor.Uspesnost)
            {
                return true;
            }
            else {
                throw new Exception(odgovor.Podaci.ToString());
            }
        }

        public bool kreirajProizvod(GamingProizvod g)
        {
            Zahtev zahtev = new Zahtev
            {
                Operacija = Operacija.KreirajProizvod,
                Podaci = g
            };
            
            this.formater.Serialize(this.stream, zahtev);
            
            Odgovor odgovor = (Odgovor)this.formater.Deserialize(this.stream);

            if (odgovor.Uspesnost)
            {
                return (bool)odgovor.Podaci;
            }
            else {
                throw new Exception(odgovor.Podaci.ToString());
            }
        }

        public IList<Nalog> vratiSveNaloge() {
            Zahtev zahtev = new Zahtev
            {
                Operacija = Operacija.VratiSveNaloge
            };
            this.formater.Serialize(this.stream, zahtev);

            Odgovor odgovor = (Odgovor)this.formater.Deserialize(this.stream);

            if (odgovor.Uspesnost)
            {
                return (IList<Nalog>) odgovor.Podaci;
            }
            else {
                throw new Exception(odgovor.Podaci.ToString());
            }

        }
        public IList<GamingProizvod> vratiSveGamingProizvode()
        {
            Zahtev zahtev = new Zahtev
            {
                Operacija = Operacija.VratiSveProizvode
            };
            this.formater.Serialize(this.stream, zahtev);

            Odgovor odg = (Odgovor)this.formater.Deserialize(this.stream);

            if (odg.Uspesnost)
            {
                return (IList<GamingProizvod>)odg.Podaci;
            }
            else {
                throw new Exception(odg.Podaci.ToString());
            }
        }

        public Zaposleni PrijaviSe(string username, string password) {

            Zahtev zahtev = new Zahtev
            {
                Operacija = Operacija.Login,
                Podaci = new Zaposleni
                {
                    KorisnickoIme = username,
                    KorisnickaSifra = password
                }

            };
            this.formater.Serialize(this.stream, zahtev);


            Odgovor odgovor = (Odgovor)this.formater.Deserialize(this.stream);

            if (odgovor.Uspesnost)
            {
                return (Zaposleni)odgovor.Podaci;
            }
            else {
                throw new Exception(odgovor.Podaci.ToString());
            }

        }

        public IList<Nalog> pretragaNaloga(string kriterijum) {
            Zahtev zahtev = new Zahtev
            {
                Operacija = Operacija.PretraziNalog,
                Podaci = kriterijum
                
            };
            this.formater.Serialize(this.stream, zahtev);

            Odgovor odgovor = (Odgovor)this.formater.Deserialize(this.stream);

            if (odgovor.Uspesnost)
            {
                return (IList<Nalog>) odgovor.Podaci;
            }
            else {
                throw new Exception(odgovor.Podaci.ToString());
            }
        }

        internal IList<GamingProizvod> pretragaProizvoda(string kriterijum)
        {
            Zahtev zahtev = new Zahtev {
                Operacija = Operacija.PretraziProizvod,
                Podaci = kriterijum
            };
            this.formater.Serialize(this.stream, zahtev);

            Odgovor odgovor = (Odgovor) this.formater.Deserialize(this.stream);

            if (odgovor.Uspesnost)
            {
                return (IList<GamingProizvod>)odgovor.Podaci;
            }
            else {
                throw new Exception(odgovor.Podaci.ToString());
            }
        }
        public bool produziNalog(Nalog n) {
            Zahtev zahtev = new Zahtev
            {
                Operacija = Operacija.PromeniNalog,
                Podaci = n

            };
            this.formater.Serialize(this.stream,zahtev);

            Odgovor odgovor =  (Odgovor)formater.Deserialize(this.stream);

            if (odgovor.Uspesnost) {
                return (bool)odgovor.Podaci;
            }
            else{
                throw new Exception(odgovor.Podaci.ToString());
            }


        }

        internal bool ObrisiNalog(Nalog n)
        {
            Zahtev zahtev = new Zahtev
            {
                Operacija = Operacija.ObrisiNalog,
                Podaci = n
            };
            this.formater.Serialize(this.stream, zahtev);

            Odgovor odgovor = (Odgovor)this.formater.Deserialize(this.stream);

            if (odgovor.Uspesnost)
            {
                return (bool)odgovor.Podaci;
            }
            else {
                throw new Exception(odgovor.Podaci.ToString());
            }
        }

        internal bool promeniGamingProizvod(GamingProizvod g)
        {
            Zahtev zahtev = new Zahtev
            {
                Operacija = Operacija.PromeniProizvod,
                Podaci = g
            };
            this.formater.Serialize(this.stream, zahtev);

            Odgovor odg = (Odgovor)this.formater.Deserialize(this.stream);

            if (odg.Uspesnost)
            {
                return (bool)odg.Podaci;
            }
            else {
                throw new Exception(odg.Podaci.ToString());
            }
        }

        internal bool obrisiGamingProizvod(GamingProizvod gp)
        {
            Zahtev zahtev = new Zahtev {
                Operacija = Operacija.IzbrisiProizvod,
                Podaci = gp
            };
            this.formater.Serialize(this.stream, zahtev);

            Odgovor odg = (Odgovor)this.formater.Deserialize(this.stream);

            if (odg.Uspesnost)
            {
                return (bool)odg.Podaci;
            }
            else {
                throw new Exception(odg.Podaci.ToString());
            }

        }
    }
}
