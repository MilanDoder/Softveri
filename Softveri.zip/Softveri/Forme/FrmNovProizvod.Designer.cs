﻿using System;

namespace Forme
{
    partial class FrmNovProizvod
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmNovProizvod));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txt_nazivProizvoda = new System.Windows.Forms.TextBox();
            this.txt_karakteristike = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_modelProizvoda = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_cenaProizvoda = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_kolicina = new System.Windows.Forms.TextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.cbx_proizvodjaci = new System.Windows.Forms.ComboBox();
            this.btn_sacuvajProizvod = new Bunifu.Framework.UI.BunifuThinButton2();
            this.label8 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Forme.Properties.Resources.PoslednjaNada___white;
            this.pictureBox1.Location = new System.Drawing.Point(25, 28);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(39, 40);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Freestyle Script", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.label1.Location = new System.Drawing.Point(81, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(166, 42);
            this.label1.TabIndex = 1;
            this.label1.Text = "Gaming Proizvod";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Freestyle Script", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(19, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 32);
            this.label2.TabIndex = 2;
            this.label2.Text = "Naziv :";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(25, 130);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(230, 1);
            this.panel1.TabIndex = 3;
            // 
            // txt_nazivProizvoda
            // 
            this.txt_nazivProizvoda.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txt_nazivProizvoda.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_nazivProizvoda.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nazivProizvoda.ForeColor = System.Drawing.Color.White;
            this.txt_nazivProizvoda.Location = new System.Drawing.Point(88, 103);
            this.txt_nazivProizvoda.Name = "txt_nazivProizvoda";
            this.txt_nazivProizvoda.Size = new System.Drawing.Size(167, 17);
            this.txt_nazivProizvoda.TabIndex = 4;
            // 
            // txt_karakteristike
            // 
            this.txt_karakteristike.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txt_karakteristike.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_karakteristike.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_karakteristike.ForeColor = System.Drawing.Color.White;
            this.txt_karakteristike.Location = new System.Drawing.Point(157, 164);
            this.txt_karakteristike.Name = "txt_karakteristike";
            this.txt_karakteristike.Size = new System.Drawing.Size(98, 17);
            this.txt_karakteristike.TabIndex = 7;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(25, 191);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(230, 1);
            this.panel2.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Freestyle Script", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(19, 156);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(132, 32);
            this.label3.TabIndex = 5;
            this.label3.Text = "Karakteristike :";
            // 
            // txt_modelProizvoda
            // 
            this.txt_modelProizvoda.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txt_modelProizvoda.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_modelProizvoda.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_modelProizvoda.ForeColor = System.Drawing.Color.White;
            this.txt_modelProizvoda.Location = new System.Drawing.Point(88, 224);
            this.txt_modelProizvoda.Name = "txt_modelProizvoda";
            this.txt_modelProizvoda.Size = new System.Drawing.Size(167, 17);
            this.txt_modelProizvoda.TabIndex = 10;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Location = new System.Drawing.Point(25, 251);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(230, 1);
            this.panel3.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Freestyle Script", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(19, 216);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 32);
            this.label4.TabIndex = 8;
            this.label4.Text = "Model :";
            // 
            // txt_cenaProizvoda
            // 
            this.txt_cenaProizvoda.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txt_cenaProizvoda.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_cenaProizvoda.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_cenaProizvoda.ForeColor = System.Drawing.Color.White;
            this.txt_cenaProizvoda.Location = new System.Drawing.Point(80, 280);
            this.txt_cenaProizvoda.Name = "txt_cenaProizvoda";
            this.txt_cenaProizvoda.Size = new System.Drawing.Size(175, 17);
            this.txt_cenaProizvoda.TabIndex = 13;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Location = new System.Drawing.Point(25, 307);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(230, 1);
            this.panel4.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Freestyle Script", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(19, 272);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 32);
            this.label5.TabIndex = 11;
            this.label5.Text = "Cena :";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Location = new System.Drawing.Point(25, 366);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(230, 1);
            this.panel5.TabIndex = 15;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Freestyle Script", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(19, 331);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 32);
            this.label6.TabIndex = 14;
            this.label6.Text = "Kolicina :";
            // 
            // txt_kolicina
            // 
            this.txt_kolicina.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txt_kolicina.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_kolicina.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_kolicina.ForeColor = System.Drawing.Color.White;
            this.txt_kolicina.Location = new System.Drawing.Point(96, 339);
            this.txt_kolicina.Name = "txt_kolicina";
            this.txt_kolicina.Size = new System.Drawing.Size(159, 17);
            this.txt_kolicina.TabIndex = 16;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.Location = new System.Drawing.Point(25, 423);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(230, 1);
            this.panel6.TabIndex = 18;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Freestyle Script", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(19, 388);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(103, 32);
            this.label7.TabIndex = 17;
            this.label7.Text = "Proizvodjac :";
            // 
            // cbx_proizvodjaci
            // 
            this.cbx_proizvodjaci.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cbx_proizvodjaci.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbx_proizvodjaci.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.cbx_proizvodjaci.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbx_proizvodjaci.ForeColor = System.Drawing.Color.White;
            this.cbx_proizvodjaci.FormattingEnabled = true;
            this.cbx_proizvodjaci.Location = new System.Drawing.Point(129, 396);
            this.cbx_proizvodjaci.Name = "cbx_proizvodjaci";
            this.cbx_proizvodjaci.Size = new System.Drawing.Size(121, 21);
            this.cbx_proizvodjaci.Sorted = true;
            this.cbx_proizvodjaci.TabIndex = 19;
            // 
            // btn_sacuvajProizvod
            // 
            this.btn_sacuvajProizvod.ActiveBorderThickness = 1;
            this.btn_sacuvajProizvod.ActiveCornerRadius = 20;
            this.btn_sacuvajProizvod.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(203)))), ((int)(((byte)(219)))));
            this.btn_sacuvajProizvod.ActiveForecolor = System.Drawing.Color.White;
            this.btn_sacuvajProizvod.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.btn_sacuvajProizvod.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.btn_sacuvajProizvod.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_sacuvajProizvod.BackgroundImage")));
            this.btn_sacuvajProizvod.ButtonText = "Sačuvaj";
            this.btn_sacuvajProizvod.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_sacuvajProizvod.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_sacuvajProizvod.ForeColor = System.Drawing.Color.White;
            this.btn_sacuvajProizvod.IdleBorderThickness = 1;
            this.btn_sacuvajProizvod.IdleCornerRadius = 20;
            this.btn_sacuvajProizvod.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.btn_sacuvajProizvod.IdleForecolor = System.Drawing.Color.White;
            this.btn_sacuvajProizvod.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.btn_sacuvajProizvod.Location = new System.Drawing.Point(68, 455);
            this.btn_sacuvajProizvod.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_sacuvajProizvod.Name = "btn_sacuvajProizvod";
            this.btn_sacuvajProizvod.Size = new System.Drawing.Size(127, 45);
            this.btn_sacuvajProizvod.TabIndex = 20;
            this.btn_sacuvajProizvod.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_sacuvajProizvod.Click += new System.EventHandler(this.btn_sacuvajProizvod_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(246, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(17, 20);
            this.label8.TabIndex = 21;
            this.label8.Text = "X";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // FrmNovProizvod
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(275, 514);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.btn_sacuvajProizvod);
            this.Controls.Add(this.cbx_proizvodjaci);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txt_kolicina);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txt_cenaProizvoda);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txt_modelProizvoda);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txt_karakteristike);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_nazivProizvoda);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmNovProizvod";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmNovProizvod";
            this.Load += new System.EventHandler(this.FrmNovProizvod_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }


        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txt_nazivProizvoda;
        private System.Windows.Forms.TextBox txt_karakteristike;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_modelProizvoda;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_cenaProizvoda;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_kolicina;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cbx_proizvodjaci;
        private Bunifu.Framework.UI.BunifuThinButton2 btn_sacuvajProizvod;
        private System.Windows.Forms.Label label8;
    }
}