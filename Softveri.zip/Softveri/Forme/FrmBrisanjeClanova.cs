﻿using Klasa;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forme
{
    public partial class FrmBrisanjeClanova : Form
    {

        private BindingList<Nalog> bindingListaNaloga = new BindingList<Nalog>();

        public FrmBrisanjeClanova()
        {
            InitializeComponent();
        }

        private void FrmBrisanjeClanova_Load(object sender, EventArgs e)
        {
            bindingListaNaloga = new BindingList<Nalog>(Kontroler.Kontroler.Instanca.vratiSveNaloge());
            dgv_BrisanjeClanova.DataSource = bindingListaNaloga;
            
        }

        private void txt_pretragaClana_TextChanged(object sender, EventArgs e)
        {
            bindingListaNaloga = new BindingList<Nalog>((BindingList<Nalog>) Kontroler.Kontroler.Instanca.PretragaNaloga(txt_pretragaClana.Text));
            dgv_BrisanjeClanova.DataSource = bindingListaNaloga;

            if (bindingListaNaloga.Count == 0 || bindingListaNaloga.Count > 1)
            {
                btn_obrisiClana.Enabled = false;
            }else
            {
                btn_obrisiClana.Enabled = true;
            }
        }

        private void btn_obrisiClana_Click(object sender, EventArgs e)
        {
            try
            {

                Nalog n = bindingListaNaloga.ElementAt(0);
                MessageBox.Show(bindingListaNaloga.ElementAt(0).ClanskiBroj + "" + bindingListaNaloga.ElementAt(0).ImePrezime);
                if (Kontroler.Kontroler.Instanca.ObrisiNalog(n))
                {
                    MessageBox.Show("Sistem je obrisao nalog!");
                }
                else {
                    throw new Exception("");
                }

            }
            catch (Exception)
            {
                MessageBox.Show("Sistem ne može da obriše nalog.");
                
            }
        }
    }
}
