﻿using Klasa;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forme
{
    public partial class FrmPrijavljivanje : Form
    {
        UnicodeEncoding ByteConverter = new UnicodeEncoding();
        RSACryptoServiceProvider RSA = new RSACryptoServiceProvider();


        public FrmPrijavljivanje()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void FrmPrijavljivanje_Load(object sender, EventArgs e)
        {
            GraphicsPath eclipseRadius = new GraphicsPath();

            eclipseRadius.StartFigure();
            eclipseRadius.AddArc(new Rectangle(0, 0, 20, 20), 180, 90);
            eclipseRadius.AddLine(20, 0, btn_potvrdi.Width - 20, 0);
            eclipseRadius.AddArc(new Rectangle(btn_potvrdi.Width-20, 0, 20, 20), -90,90);
            eclipseRadius.AddLine(btn_potvrdi.Width, 20, btn_potvrdi.Width, btn_potvrdi.Height-20);
            eclipseRadius.AddArc(new Rectangle(btn_potvrdi.Width-20,btn_potvrdi.Height-20,20,20), 0,90);
            eclipseRadius.AddLine(btn_potvrdi.Width-20, btn_potvrdi.Height,20,btn_potvrdi.Height);
            eclipseRadius.AddArc(new Rectangle(0, btn_potvrdi.Height-20, 20, 20), 90, 90);
            
            eclipseRadius.CloseFigure();

            btn_potvrdi.Region = new Region(eclipseRadius);

        }

        private void label1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btn_potvrdi_Click(object sender, EventArgs e)
        {

            
            if (String.IsNullOrWhiteSpace(txt_Username.Text)
                    || String.IsNullOrWhiteSpace(txt_password.Text)) {
                MessageBox.Show("Korisnicko ime i sifra su obavezna polja!");
            } else {


                try
                {
                    /*
                    byte[] encryptedtext;
                    byte []plaintext = ByteConverter.GetBytes(txt_Username.Text);
                    encryptedtext = Encryption(plaintext, RSA.ExportParameters(false), false);
                  //MessageBox.Show(ByteConverter.GetString(encryptedtext));

                    byte[] decryptedtex = Decryption(encryptedtext, RSA.ExportParameters(true), false);
                  //MessageBox.Show( ByteConverter.GetString(decryptedtex));
                  */

                    Zaposleni z = Komunikacija.Instanca.PrijaviSe(txt_Username.Text.Trim(),txt_password.Text.Trim());
                    frm_glavna glavna = new frm_glavna(z);
                    glavna.Show();
                    this.Hide();
                    this.Owner = glavna;
                }
                catch (Exception)
                {
                    MessageBox.Show("Greska123!");
                    
                }
            }
        }




        /// <summary>
        /// Enxryption RSA
        /// </summary>
        /// <param name="Data"></param>
        /// <param name="RSAKey"></param>
        /// <param name="DoOAEPPadding"></param>
        /// <returns></returns>
        static public byte[] Encryption(byte[] Data, RSAParameters RSAKey, bool DoOAEPPadding)
        {
            try
            {
                byte[] encryptedData;
                using (RSACryptoServiceProvider RSA = new RSACryptoServiceProvider())
                {
                    RSA.ImportParameters(RSAKey); encryptedData = RSA.Encrypt(Data, DoOAEPPadding);
                }
                return encryptedData;
            }
            catch (CryptographicException e)
            {
                Console.WriteLine(e.Message);
                return null;
            }
        }
        /// <summary>
        /// Decryption
        ///
        /// </summary>
        /// <param name="Data"></param>
        /// <param name="RSAKey"></param>
        /// <param name="DoOAEPPadding"></param>
        /// <returns></returns>
        static public byte[] Decryption(byte[] Data, RSAParameters RSAKey, bool DoOAEPPadding)
        {
            try
            {
                byte[] decryptedData;
                using (RSACryptoServiceProvider RSA = new RSACryptoServiceProvider())
                {
                    RSA.ImportParameters(RSAKey);
                    decryptedData = RSA.Decrypt(Data, DoOAEPPadding);
                }
                return decryptedData;
            }
            catch (CryptographicException e)
            {
                Console.WriteLine(e.ToString());
                return null;
            }
        }

        void vratiKriptovanoUsernameIPassword(out byte[] encrypt, out byte[] encryptpass, out string username, out string password) {
           
            byte[] encryptedtext;
            byte[] encryptedPass;

            encryptedtext = Encryption(ByteConverter.GetBytes(txt_Username.Text), RSA.ExportParameters(false), false);
            username = ByteConverter.GetString(encryptedtext);
            encrypt = encryptedtext;
            encryptedPass = Encryption(ByteConverter.GetBytes(txt_password.Text), RSA.ExportParameters(false), false);
            password = ByteConverter.GetString(encryptedPass);
            encryptpass = encryptedPass;

        }
        void vratiDekriptovanoUserIPass( string username, string password, out string user, out string pass)
        {
            byte[] decryptedtex = Decryption(ByteConverter.GetBytes(username), RSA.ExportParameters(true), false);
            user = ByteConverter.GetString(decryptedtex);


            pass = ByteConverter.GetString(Decryption(ByteConverter.GetBytes(password), RSA.ExportParameters(true), false));
        }
    }
}
