﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forme
{
    public partial class Login : Form
    {
        //Privremeneno 
        private string username = "k1";
        private string password = "k1";
        public Login()
        {
            InitializeComponent();
        }

        private void btn_potvrdi_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrWhiteSpace(txt_korsinIme.Text) ||
                String.IsNullOrWhiteSpace(txt_sifra.Text)) {
                MessageBox.Show("Korisnicko ime i sifra su obavezna polja!");
            }
            else {




                try
                {
                    //Probna verzija prijavljivanj
                    MessageBox.Show(txt_korsinIme.Text + " " +
                                    txt_sifra.Text);

                    if (txt_korsinIme.Text == username &&
                        txt_sifra.Text == password)
                    {
                        GlavnaForma gf = new GlavnaForma();
                        gf.Show();
                        this.Hide();
                        this.Owner = gf;
                    }
                    else {

                        MessageBox.Show("Greska pri prijavljivanju!");
                    }
                }
                catch (Exception ex)
                {

                    MessageBox.Show("greska");
                }
            }
        }
    }
}
