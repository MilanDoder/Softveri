﻿using Klasa;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forme
{
    public partial class UnosProizvoda : Form
    {
        public UnosProizvoda()
        {
            InitializeComponent();

           // IList<Proizvodjac> listaProzvodjaca = Kontroler.Kontroler.Instanca.VratiSveProizvodjace();
            //cbx_proizvodjac.DataSource = listaProzvodjaca;
            cbx_proizvodjac.DisplayMember = "Naziv";
            
        }

        

        private void btn_Sacuvaj_Click(object sender, EventArgs e)
        {
            GlavnaForma gf = new GlavnaForma();

            gf.Show();
            this.Hide();
            this.Owner = gf;
        }

        private void UnosProizvoda_Load(object sender, EventArgs e)
        {

        }
    }
}
