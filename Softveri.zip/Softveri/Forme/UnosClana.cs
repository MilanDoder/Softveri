﻿using Klasa;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forme
{
    public partial class UnosClana : Form
    {

        static Regex ValidEmailRegex = CreateValidEmailRegex();
        public UnosClana()
        {
            InitializeComponent();
        }

        //private void btn_sacuvajClana_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        int clBroj =46543132;
        //       /* do {
        //            clBroj = 44081862;
        //        } while (!Kontroler.Kontroler.Instanca.ispravnostClanskogBroja(clBroj));
        //        */
        //        //Doraditi
        //        ValidacijaPodataka();
        //        MessageBox.Show(clBroj.ToString());
        //        Nalog n = new Nalog
        //        {
        //            ClanskiBroj = clBroj,
        //            ImePrezime = txt_imeClana.Text + " " + txt_prezimeClana.Text,
        //            KontaktTelefon = txt_telefonClana.Text,
        //            Email = txt_emailClana.Text,
        //            Adresa = txt_AdresaStanovanja.Text
                   

        //        };
                
        //        Kontroler.Kontroler.Instanca.sacuvajClanskiNalog(n);
        //        MessageBox.Show("Nalog je sacuvan");
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("Greska pri unosu clana");
        //    }
        //}


        private  void ValidacijaPodataka() {
             bool uspesno = true;
            txt_imeClana.BackColor = Color.White;
            txt_prezimeClana.BackColor = Color.White;
            txt_emailClana.BackColor = Color.White;
            txt_telefonClana.BackColor = Color.White;
            txt_AdresaStanovanja.BackColor = Color.White;

            if (String.IsNullOrWhiteSpace(txt_imeClana.Text)) {
                txt_imeClana.BackColor = Color.IndianRed;
                uspesno = false;
            }
            if (String.IsNullOrWhiteSpace(txt_prezimeClana.Text)) {
                txt_prezimeClana.BackColor = Color.IndianRed;
                uspesno = false;
            }

            if (String.IsNullOrWhiteSpace(txt_telefonClana.Text) && !IsValidPhone(txt_telefonClana.Text))
            {
                txt_telefonClana.BackColor = Color.IndianRed;
                uspesno = false;
            }
            if (String.IsNullOrWhiteSpace(txt_emailClana.Text) && !EmailIsValid(txt_emailClana.Text))
            {
                txt_emailClana.BackColor = Color.IndianRed;
                uspesno = false;
            }
            if (String.IsNullOrWhiteSpace(txt_AdresaStanovanja.Text)) {
                txt_AdresaStanovanja.BackColor = Color.IndianRed;
                uspesno = false;
            }
            
           


            if (!uspesno) {
                throw new Exception("Niste uneli ispravne podatke");
            }
        }


        private static Regex CreateValidEmailRegex()
        {
            string validEmailPattern = @"^(?!\.)(""([^""\r\\]|\\[""\r\\])*""|"
                + @"([-a-z0-9!#$%&'*+/=?^_`{|}~]|(?<!\.)\.)*)(?<!\.)"
                + @"@[a-z0-9][\w\.-]*[a-z0-9]\.[a-z][a-z\.]*[a-z]$";

            return new Regex(validEmailPattern, RegexOptions.IgnoreCase);
        }

        internal static bool EmailIsValid(string emailAddress)
        {
            bool isValid = ValidEmailRegex.IsMatch(emailAddress);

            return isValid;
        }

        public bool IsValidPhone(string Phone)
        {
            string patternPhoneNumber = @"^((\+\d{1,3}(-| )?\(?\d\)?(-| )?\d{1,5})|(\(?\d{2,6}\)?))(-| )?(\d{3,4})(-| )?(\d{4})(( x| ext)\d{1,5}){0,1}$";
            try
            {    
                var r = new Regex(patternPhoneNumber);
                return r.IsMatch(Phone);
            }
            catch (Exception)
            {
                throw;
            }
        }


    }
}
