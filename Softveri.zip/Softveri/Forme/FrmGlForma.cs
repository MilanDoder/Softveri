﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Klasa;
using System.IO;

namespace Forme
{
    public partial class frm_glavna : Form
    {
        string _MybackgroungColor = "#222431";
        string _MyLetterColor = "#4eb8ce";
        private Zaposleni _z;

        private BindingList<Nalog> _listaNaloga = new BindingList<Nalog>();
        private BindingList<GamingProizvod> _listaGamingProizvoda = new BindingList<GamingProizvod>();
       

        // System.Drawing.Color col = System.Drawing.ColorTranslator.FromHtml("#FFCC66");

        public frm_glavna()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            pnl_left.Hide();
            dgv_podaci.Show();
            pnl_prikazElemenata.Size = new Size(0, 0);
        }

        public frm_glavna(Zaposleni z)
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            pnl_left.Hide();
            _z = z;
            lbl_zaposleniIme.Text = _z.Ime + " " + _z.Prezime;
            //Forme.Properties.Resources.userWhite
            string url = @"C:\Users\Miki\Desktop\Aplikacija-Softveri\Softveri\Softveri\Forme\Resources\controlers1.jpg";
            string slika = $"C:\\Users\\Miki\\Desktop\\Aplikacija-Softveri\\Softveri\\Softveri\\Forme\\Resources\\{_z.Image}";
            
            pcb_slikaZaposlenog.Image = Image.FromFile(slika);
            btn_pretraga.Enabled = false;
        }

        

        private void lbl_imePrezimeZaposlenog_Click(object sender, EventArgs e)
        {

        }

        private void FrmGlForma_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            Close();
        }

       

        private void btn_clanovi_Click(object sender, EventArgs e)
        {
            lbl_selektovaniNaziv.Text = btn_clanovi.ButtonText;
            try
            {
                // System.Drawing.Color col = System.Drawing.ColorTranslator.FromHtml("#FFCC66");
                btn_proizvodi.IdleBorderColor = ColorTranslator.FromHtml(_MybackgroungColor);
                btn_narudzbenica.IdleBorderColor = ColorTranslator.FromHtml(_MybackgroungColor);
                btn_clanovi.IdleBorderColor = ColorTranslator.FromHtml(_MyLetterColor);
                pnl_selektovanoDugme.BackColor = ColorTranslator.FromHtml(_MyLetterColor);
                btn_kreiraj.ButtonText = "Kreiraj";
                btn_promeni.ButtonText = "Promeni";
                btn_promeni.Enabled = false;
                btn_Obrisi.Enabled = false;
                pnl_left.Show();
                pnl_selektovanoDugme.Location = new Point(0, 109);
                btn_pretraga.Enabled = true;
  

                ///Prikaz svih naloga
                ///     
                _listaNaloga =  new BindingList<Nalog>(Komunikacija.Instanca.vratiSveNaloge());
                dgv_podaci.DataSource = _listaNaloga;


            }
            catch (Exception)
            {
                MessageBox.Show("Greska pri promeni selekcije");
            }
        }

        private void btn_narudzbenica_Click(object sender, EventArgs e)
        {
            lbl_selektovaniNaziv.Text = btn_narudzbenica.ButtonText;
            try
            {
                // System.Drawing.Color col = System.Drawing.ColorTranslator.FromHtml("#FFCC66");
                btn_proizvodi.IdleBorderColor = ColorTranslator.FromHtml(_MybackgroungColor);
                btn_clanovi.IdleBorderColor = ColorTranslator.FromHtml(_MybackgroungColor) ;
                btn_narudzbenica.IdleBorderColor = ColorTranslator.FromHtml(_MyLetterColor);
                pnl_selektovanoDugme.BackColor = ColorTranslator.FromHtml(_MyLetterColor);
                pnl_left.Show();
                btn_kreiraj.ButtonText = "Kreiraj";
                btn_promeni.ButtonText = "Ažuriraj";
                btn_promeni.Enabled = false;
                btn_Obrisi.Enabled = false;
                pnl_selektovanoDugme.Location = new Point(0, 147);

                btn_pretraga.Enabled = true;

            }
            catch (Exception)
            {
                MessageBox.Show("Greska pri promeni selekcije");
            }
           
        }

        private void btn_proizvodi_Click(object sender, EventArgs e)
        {
            lbl_selektovaniNaziv.Text = btn_proizvodi.ButtonText;
            try
            {
                // System.Drawing.Color col = System.Drawing.ColorTranslator.FromHtml("#FFCC66");
                
                btn_clanovi.IdleBorderColor = ColorTranslator.FromHtml(_MybackgroungColor);
                btn_narudzbenica.IdleBorderColor = ColorTranslator.FromHtml(_MybackgroungColor);
                btn_proizvodi.IdleBorderColor = ColorTranslator.FromHtml(_MyLetterColor);
                pnl_selektovanoDugme.BackColor = ColorTranslator.FromHtml(_MyLetterColor);
                pnl_left.Show();
                btn_kreiraj.ButtonText = " Nov";
                btn_promeni.ButtonText = "Promeni";
                btn_promeni.Enabled = false;
                btn_Obrisi.Enabled = false;
                pnl_selektovanoDugme.Location = new Point(0, 185);

                btn_pretraga.Enabled = true;

                _listaGamingProizvoda = new BindingList<GamingProizvod>(Komunikacija.Instanca.ucitajGamingProizvode());
                dgv_podaci.DataSource = _listaGamingProizvoda;
                
            }
            catch (Exception)
            {
                MessageBox.Show("Greska pri promeni selekcije");
            }

        }

        private void btn_odjava_Click(object sender, EventArgs e)
        {
            FrmPrijavljivanje prijava = new FrmPrijavljivanje();
            this.Hide();
            this.Owner = prijava;
            prijava.ShowDialog();
            
        }

        private void btn_pretraga_TextChange(object sender, EventArgs e)
        {
            //Omoguca pretrazivanje naloga
            if (pnl_selektovanoDugme.Location.X.Equals(0) && pnl_selektovanoDugme.Location.Y.Equals(109) ) {
                _listaNaloga = new BindingList<Nalog>(Komunikacija.Instanca.pretragaNaloga(btn_pretraga.Text));
                dgv_podaci.DataSource = _listaNaloga;

            }
            if (pnl_selektovanoDugme.Location == (new Point(0, 147)))
            {
                btn_pretraga.BackColor = Color.Yellow;
            }
            //pretrazivanje proizvoda
            if (pnl_selektovanoDugme.Location == (new Point(0, 185)))
            {
                _listaGamingProizvoda = new BindingList<GamingProizvod>(Komunikacija.Instanca.pretragaProizvoda(btn_pretraga.Text));
                dgv_podaci.DataSource = _listaGamingProizvoda;
                btn_pretraga.BackColor = Color.Green;
            }
        }

        public Image stringToImage(string inputString)
        {
            byte[] imageBytes = Encoding.Unicode.GetBytes(inputString);

            // Don't need to use the constructor that takes the starting offset and length
            // as we're using the whole byte array.
            MemoryStream ms = new MemoryStream(imageBytes);

            Image image = Image.FromStream(ms, true, true);

            return image;
        }

        private void btn_kreiraj_Click(object sender, EventArgs e)
        {
            if (pnl_selektovanoDugme.Location == (new Point(0, 109))) {
                FrmKreirajNalog kNalog = new FrmKreirajNalog();
                kNalog.ShowDialog();
                
                _listaNaloga = new BindingList<Nalog>(Komunikacija.Instanca.vratiSveNaloge());
                dgv_podaci.DataSource = _listaNaloga;
                dgv_podaci.Refresh();
            }
            if (pnl_selektovanoDugme.Location == new Point(0, 147)) {

            }

            if (pnl_selektovanoDugme.Location == new Point(0, 185)) {
                FrmNovProizvod kProizvod = new FrmNovProizvod();
                kProizvod.ShowDialog();
                _listaGamingProizvoda = new BindingList<GamingProizvod>(Komunikacija.Instanca.ucitajGamingProizvode());
                    dgv_podaci.DataSource = _listaGamingProizvoda;
                 dgv_podaci.Refresh();
            }
        }

        private void btn_Obrisi_Click(object sender, EventArgs e)
        {
            if (pnl_selektovanoDugme.Location == new Point(0, 109)) {
                try
                {
                    Nalog n = vratiNalogIzPomocneForme();
                    if (Komunikacija.Instanca.ObrisiNalog(n))
                    {
                        MessageBox.Show("Nalog je obrisan!");
                        pnl_prikazElemenata.Hide();
                        ukljuciDugmad();
                        _listaNaloga = new BindingList<Nalog>(Komunikacija.Instanca.vratiSveNaloge());
                        dgv_podaci.DataSource = _listaNaloga;
                        dgv_podaci.Refresh();
                    }
                    else {
                        throw new Exception();
                    }
                }
                catch (Exception)
                {

                    MessageBox.Show("Nalog ne moze da se obrise!");
                }
                
                
            }
            if (pnl_selektovanoDugme.Location == new Point(0, 147)) {
                obrisiNarudzbenicu();
            }
            if (pnl_selektovanoDugme.Location == new Point(0, 185)) {
                try
                {
                    GamingProizvod gp = vratiGamingProizvodIzPomocneForme();

                    if (Komunikacija.Instanca.obrisiGamingProizvod(gp)){
                        MessageBox.Show("Proizvod obrisan!");
                        pnl_izabraniGamingProizvod.Hide();
                        ukljuciDugmad();
                        _listaGamingProizvoda = new BindingList<GamingProizvod>(Komunikacija.Instanca.ucitajGamingProizvode());
                        dgv_podaci.DataSource = _listaGamingProizvoda;
                        dgv_podaci.Refresh();
                    }
                    else {
                        MessageBox.Show("Proizvod ne moze da se obrise!");
                    }

                }
                catch (Exception)
                {

                    throw;
                }
            }
        }
        //private void obrisiClanskiNalog()
        //{
        //    try
        //    {
        //        Nalog n = new Nalog
        //        {
        //            ClanskiBroj = Convert.ToInt32(lbl_clanskiBrojIzabranogClana.Text),

        //        };

        //        if (Kontroler.Kontroler.Instanca.ObrisiNalog(n))
        //        {

        //            MessageBox.Show("Sistem je obrisao nalog!");
        //            pnl_prikazElemenata.Hide();
        //            ukljuciDugmad();
        //            _listaNaloga = new BindingList<Nalog>(Kontroler.Kontroler.Instanca.VratiSveClanove());
        //            dgv_podaci.DataSource = _listaNaloga;
        //            dgv_podaci.Refresh();
        //        }
        //        else
        //        {
        //            throw new Exception("");
        //        }


        //    }
        //    catch (Exception)
        //    {
        //        MessageBox.Show("Sistem ne može da obriše nalog.");

        //    }
        //}

        private void obrisiGamingProizvod()
        {

            try
            {
                GamingProizvod proizvod = new GamingProizvod
                {
                    proizvodID = Convert.ToInt32(lbl_ProizvodID.Text)
                };

            //    if (kontroler.kontroler.instanca.obrisigamingproizvod(proizvod))
            //        //{
            //        messagebox.show("sistem je obrisao gaming proizvod.");
            //    pnl_izabranigamingproizvod.visible = false;
            //    ukljucidugmad();
            //    _listagamingproizvoda = new bindinglist<gamingproizvod>(kontroler.kontroler.instanca.ucitajgamingproizvode());
            //    dgv_podaci.datasource = _listagamingproizvoda;
            //    dgv_podaci.refresh();



            //}
            //    else {
            //    throw new exception();
            //}


        }
            catch (Exception)
            {

                MessageBox.Show("Sistem ne moze da obrise Gaming proizvod.");
            }
        }

        private void obrisiNarudzbenicu()
        {
            throw new NotImplementedException();
        }

        private void btn_promeni_Click(object sender, EventArgs e)
        {
            ///U pitanju su nalozi
            if (pnl_selektovanoDugme.Location == new Point(0, 109))
            {
                try
                {
                    Nalog n = vratiNalogIzPomocneForme();

                    if (Komunikacija.Instanca.produziNalog(n))
                    {
                        MessageBox.Show("Nalog je produzen!");
                        pnl_prikazElemenata.Hide();
                        ukljuciDugmad();
                        _listaNaloga = new BindingList<Nalog>(Komunikacija.Instanca.vratiSveNaloge());
                        dgv_podaci.DataSource = _listaNaloga;
                        dgv_podaci.Refresh();
                    }
                    else {
                        throw new Exception();
                    }
                }
                catch (Exception)
                {

                    MessageBox.Show("Sistem ne moze da produzi nalog!");
                }
                dgv_podaci.Refresh();


            } else if (pnl_selektovanoDugme.Location == new Point(0, 147)) {

            } else if (pnl_selektovanoDugme.Location == new Point(0,185)) {
                try
                {
                    GamingProizvod g = vratiGamingProizvodIzPomocneForme();
                    MessageBox.Show("Proizvod : \n" + g.Naziv + "\n " + g.proizvodID + "\nProizvodjac : \n" + g.proizvodjac.ProizvodjacID + "\n" + g.proizvodjac.Naziv);

                    if (Komunikacija.Instanca.promeniGamingProizvod(g))
                    {
                        MessageBox.Show("Uspesno je promenjen Gaming Proizvod!");
                        pnl_izabraniGamingProizvod.Hide();
                        ukljuciDugmad();
                        ///SMEM LI OVO OVAKO
                        _listaGamingProizvoda = new BindingList<GamingProizvod>(Komunikacija.Instanca.vratiSveGamingProizvode());
                        dgv_podaci.DataSource = _listaGamingProizvoda;
                        dgv_podaci.Refresh();
                    }
                    else {

                    }
                }
                catch (Exception)
                {

                    throw;
                }
            }
        }

        private GamingProizvod vratiGamingProizvodIzPomocneForme()
        {
            return new GamingProizvod
            {
                proizvodID = Convert.ToInt32(lbl_ProizvodID.Text),
                model = lbl_modelGProizvoda.Text,
                cena = Convert.ToInt32(txt_cenaIzabranogGamingProizvoda.Text),
                Naziv = lbl_nazivGProizvoda.Text,
                karakteristike = txt_karakteristikeIzabranogGamingProizvoda.Text,
                raspolozivoStanje = Convert.ToInt32(txt_kolicinaIzabranogGamingProizvoda.Text),
                proizvodjac = new Proizvodjac
                {
                    ProizvodjacID = Convert.ToInt32(lbl_proizvodjacID.Text),
                    Naziv = lbl_nazivProizvodjacaIzbProizvoda.Text,
                    Adresa = txt_adresaIzabranogProizvodjaca.Text,
                    Telefon = txt_telefonIzabranogProizvodjac.Text
                }


            };
        }

        private void dgv_podaci_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (pnl_selektovanoDugme.Location == new Point(0, 109))
                {

                    int broj = Convert.ToInt32(dgv_podaci.Rows[e.RowIndex].Cells[0].Value.ToString());
                    Nalog n = vratiNalogIzListe(broj);
                    pnl_prikazElemenata.Show();
                    pnl_prikazElemenata.Size = new Size(447, 297);
                    pnl_prikazElemenata.Location = new Point(166, 61);

                    pozoviFormuZaPromenuNaloga(n);
                    IskljuciDugmad();

                }

                if (pnl_selektovanoDugme.Location == new Point(0, 147))
                {
                    MessageBox.Show("Work");
                }

                if (pnl_selektovanoDugme.Location == new Point(0, 185))
                {
                    /*int idProizvod = Kontroler.Kontroler.Instanca.vratiNajveciIDProizvoda(
                        dgv_podaci.Rows[e.RowIndex].Cells[0].Value.ToString(),
                        dgv_podaci.Rows[e.RowIndex].Cells[1].Value.ToString(),
                        dgv_podaci.Rows[e.RowIndex].Cells[4].Value.ToString());
                        */
                    //GamingProizvod gproizvod = vratiGamingProizvod(idProizvod);

                    //prikazGamingProizvoda(gproizvod);
                    //pnl_izabraniGamingProizvod.Visible = true;
                    //IskljuciDugmad();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Greska pri citanju podataka");
            }
        }

        private void prikazGamingProizvoda(GamingProizvod gproizvod)
        {
            lbl_ProizvodID.Text = gproizvod.proizvodID.ToString();
            lbl_nazivGProizvoda.Text = gproizvod.Naziv;
            lbl_modelGProizvoda.Text = gproizvod.model;
            lbl_nazivProizvodjacaIzbProizvoda.Text = gproizvod.proizvodjac.Naziv;
            txt_cenaIzabranogGamingProizvoda.Text = gproizvod.cena.ToString();
            txt_kolicinaIzabranogGamingProizvoda.Text = gproizvod.raspolozivoStanje.ToString();
            txt_karakteristikeIzabranogGamingProizvoda.Text = gproizvod.karakteristike;

            txt_telefonIzabranogProizvodjac.Text = gproizvod.proizvodjac.Telefon;
            txt_adresaIzabranogProizvodjaca.Text = gproizvod.proizvodjac.Adresa;

           
          
        }

        private GamingProizvod vratiGamingProizvod(int idProizvod)
        {
            foreach (var proizvod in _listaGamingProizvoda) {
                if (proizvod.proizvodID == idProizvod) {
                    return proizvod;
                }
            }
            return null;
        }

        /// <summary>
        /// Forma za unos novog clana 
        /// Njen prikaz
        /// </summary>
        /// <param name="n"></param>
        private void pozoviFormuZaPromenuNaloga(Nalog n) {
            lbl_clanskiBrojIzabranogClana.Text = n.ClanskiBroj.ToString();
            txt_imeIzabranogClana.Text = n.ImePrezime.Substring(0, n.ImePrezime.IndexOf(" "));
            txt_prezimeIzabranogClana.Text = n.ImePrezime.Substring(n.ImePrezime.IndexOf(" ") + 1);
            txt_telefonIzabranogClana.Text = n.KontaktTelefon;
            txt_emailIzbranogClana.Text = n.Email;
            txt_adresaIzabranogClana.Text = n.Adresa;
        }

        /// <summary>
        /// Za sada ne potrebna
        /// </summary>
        /// <returns></returns>
        private Nalog napraviNalogPrekoTabele(DataGridViewCellEventArgs e) {
            return new Nalog {
                ClanskiBroj = Convert.ToInt32(dgv_podaci.Rows[e.RowIndex].Cells[0].Value.ToString()),
                ImePrezime = dgv_podaci.Rows[e.RowIndex].Cells[1].Value.ToString(),
                KontaktTelefon = dgv_podaci.Rows[e.RowIndex].Cells[2].Value.ToString(),
                Email = dgv_podaci.Rows[e.RowIndex].Cells[3].Value.ToString(),
                Adresa = dgv_podaci.Rows[e.RowIndex].Cells[4].Value.ToString()
            };
        }

        private void IskljuciDugmad()
        {
            btn_kreiraj.Enabled = false;
            btn_promeni.Enabled = true;
            btn_Obrisi.Enabled = true;
            btn_proizvodi.Enabled = false;
            btn_narudzbenica.Enabled = false;
            btn_odjava.Enabled = false;
            btn_clanovi.Enabled = false;
            btn_pretraga.Enabled = false;
        }
        private void ukljuciDugmad()
        {
            btn_kreiraj.Enabled = true;
            btn_promeni.Enabled = false;
            btn_Obrisi.Enabled = false;
            btn_proizvodi.Enabled = true;
            btn_narudzbenica.Enabled = true;
            btn_odjava.Enabled = true;
            btn_clanovi.Enabled = true;
            btn_pretraga.Enabled = true;
        }


        private void btn_ponistiPromene_Click(object sender, EventArgs e)
        {

            ukljuciDugmad();
            pnl_prikazElemenata.Hide();
            
        }

        private void btn_nazadProizvod_Click(object sender, EventArgs e)
        {
            ukljuciDugmad();
            pnl_izabraniGamingProizvod.Visible = false;
        }


        /// <summary>
        /// Popraviti nacin za brisanje clanova
        /// obratiti paznju na narudzbenicu i pproizvod
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>


        private Nalog vratiNalogIzPomocneForme() {

            return new Nalog
            {
                ClanskiBroj = Convert.ToInt32(lbl_clanskiBrojIzabranogClana.Text),
                ImePrezime = txt_imeIzabranogClana.Text + " "+ txt_prezimeIzabranogClana.Text,
                KontaktTelefon = txt_telefonIzabranogClana.Text,
                Email = txt_emailIzbranogClana.Text,
                Adresa = txt_adresaIzabranogClana.Text


            };
        }

        private Nalog vratiNalogIzListe(int clanskiBroj) {

            foreach (var nalog in _listaNaloga)
            {
                if (clanskiBroj == nalog.ClanskiBroj)
                    return nalog;
            }

            throw new Exception("Greska pri vracanju naloga");
        }

        private void lbl_plusMinusKar_Click(object sender, EventArgs e)
        {
            if (lbl_plusMinusKar.Text == "+") {
                lbl_plusMinusKar.Text = "-";
                txt_karakteristikeIzabranogGamingProizvoda.Visible = true;
                pnl_plusUMinusProizvodjac.Location = new Point(pnl_plusUMinusKarakteristike.Location.X,pnl_plusUMinusKarakteristike.Location.Y+95);
                lbl_proizvodjacIzbProizvda.Location = new Point(pnl_plusUMinusKarakteristike.Location.X+26, pnl_plusUMinusKarakteristike.Location.Y + 95);
                lbl_nazivProizvodjacaIzbProizvoda.Location = new Point(lbl_proizvodjacIzbProizvda.Location.X + 84, lbl_proizvodjacIzbProizvda.Location.Y + 10);
                pnl_podaciIzabranogProizvodjaca.Location = new Point(lbl_proizvodjacIzbProizvda.Location.X + 5, lbl_proizvodjacIzbProizvda.Location.Y + 28);
            }
            else { 
                lbl_plusMinusKar.Text = "+";
                pnl_plusUMinusProizvodjac.Location = new Point(pnl_plusUMinusKarakteristike.Location.X, pnl_plusUMinusKarakteristike.Location.Y+42);
                txt_karakteristikeIzabranogGamingProizvoda.Visible = false;
                lbl_proizvodjacIzbProizvda.Location = new Point(pnl_plusUMinusKarakteristike.Location.X + 26, pnl_plusUMinusKarakteristike.Location.Y + 42);
                lbl_nazivProizvodjacaIzbProizvoda.Location = new Point(lbl_proizvodjacIzbProizvda.Location.X + 84, lbl_proizvodjacIzbProizvda.Location.Y + 10);
                pnl_podaciIzabranogProizvodjaca.Location = new Point(lbl_proizvodjacIzbProizvda.Location.X + 5, lbl_proizvodjacIzbProizvda.Location.Y + 28);

            }
        }

        private void lbl_minusUPlusProiz_Click(object sender, EventArgs e)
        {
            if (lbl_minusUPlusProiz.Text == "+")
            {
                lbl_minusUPlusProiz.Text = "-";
                if (lbl_plusMinusKar.Text == "+")
                {
                    //promeni poziciju gore
                    pnl_podaciIzabranogProizvodjaca.Location = new Point(lbl_proizvodjacIzbProizvda.Location.X + 5, lbl_proizvodjacIzbProizvda.Location.Y + 28);
                }
                if (lbl_plusMinusKar.Text == "-") {
                    pnl_podaciIzabranogProizvodjaca.Location = new Point(lbl_proizvodjacIzbProizvda.Location.X + 5, lbl_proizvodjacIzbProizvda.Location.Y + 28);

                }

                pnl_podaciIzabranogProizvodjaca.Visible = true;
               
            }
            else {
                lbl_minusUPlusProiz.Text = "+";
                pnl_podaciIzabranogProizvodjaca.Visible = false;
                pnl_podaciIzabranogProizvodjaca.Location = new Point(lbl_proizvodjacIzbProizvda.Location.X + 5, lbl_proizvodjacIzbProizvda.Location.Y + 28);

            }
        }

        private void dgv_podaci_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (pnl_selektovanoDugme.Location == new Point(0, 109))
            {

                int broj = Convert.ToInt32(dgv_podaci.Rows[e.RowIndex].Cells[0].Value.ToString());
                Nalog n = vratiNalogIzListe(broj);
                pnl_prikazElemenata.Show();
                pnl_prikazElemenata.Size = new Size(447, 297);
                pnl_prikazElemenata.Location = new Point(166, 61);

                pozoviFormuZaPromenuNaloga(n);
                IskljuciDugmad();

            }
            else if (pnl_selektovanoDugme.Location == new Point(0, 147))
            {

            }
            else if (pnl_selektovanoDugme.Location == new Point(0,185)) {

                MessageBox.Show("Izabran proizvod!");
                string igrica = dgv_podaci.Rows[e.RowIndex].Cells[0].Value.ToString();
                string model = dgv_podaci.Rows[e.RowIndex].Cells[1].Value.ToString();

                GamingProizvod proizvod = vratiProizvod(igrica.Trim(), model.Trim());

                pnl_izabraniGamingProizvod.Show();
                pnl_izabraniGamingProizvod.Size = new Size(447, 255);

                pozoviFormuZaGamingProizvod(proizvod);
                IskljuciDugmad();


            }
        }

        private void pozoviFormuZaGamingProizvod(GamingProizvod proizvod)
        {
            lbl_nazivGProizvoda.Text = proizvod.Naziv;
            lbl_modelGProizvoda.Text = proizvod.model;
            txt_cenaIzabranogGamingProizvoda.Text = proizvod.cena.ToString();
            txt_karakteristikeIzabranogGamingProizvoda.Text = proizvod.karakteristike.ToString();
            txt_kolicinaIzabranogGamingProizvoda.Text = proizvod.raspolozivoStanje.ToString();
            lbl_nazivProizvodjacaIzbProizvoda.Text = proizvod.proizvodjac.Naziv;
            txt_telefonIzabranogProizvodjac.Text = proizvod.proizvodjac.Telefon;
            txt_adresaIzabranogProizvodjaca.Text = proizvod.proizvodjac.Adresa;
            lbl_ProizvodID.Text = proizvod.proizvodID.ToString();
            lbl_proizvodjacID.Text = proizvod.proizvodjac.ProizvodjacID.ToString();
        }

        private GamingProizvod vratiProizvod(string igrica, string model)
        {
            foreach (var proizvod in _listaGamingProizvoda)
            {
                if(proizvod.Naziv.Trim().Equals(igrica.Trim()) && proizvod.model.Trim().Equals(model.Trim()))
                {
                    return proizvod;
                }
            }
            return null;
        }
    }
}
