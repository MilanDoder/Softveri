﻿namespace Forme
{
    partial class FrmKreirajNalog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmKreirajNalog));
            this.pnl_imeClana = new System.Windows.Forms.Panel();
            this.txt_ImeClana = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_prezimeClana = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txt_telefonClana = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txt_emailClana = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txt_adresaClana = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btn_sacuvaj = new Bunifu.Framework.UI.BunifuThinButton2();
            this.pcb_adresaClana = new System.Windows.Forms.PictureBox();
            this.pcb_emailClana = new System.Windows.Forms.PictureBox();
            this.pcb_telefonClana = new System.Windows.Forms.PictureBox();
            this.pcb_prezimeClana = new System.Windows.Forms.PictureBox();
            this.pcb_imeClana = new System.Windows.Forms.PictureBox();
            this.lbl_closeNalog = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pcb_adresaClana)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcb_emailClana)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcb_telefonClana)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcb_prezimeClana)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcb_imeClana)).BeginInit();
            this.SuspendLayout();
            // 
            // pnl_imeClana
            // 
            this.pnl_imeClana.BackColor = System.Drawing.Color.White;
            this.pnl_imeClana.Location = new System.Drawing.Point(30, 109);
            this.pnl_imeClana.Name = "pnl_imeClana";
            this.pnl_imeClana.Size = new System.Drawing.Size(250, 1);
            this.pnl_imeClana.TabIndex = 1;
            // 
            // txt_ImeClana
            // 
            this.txt_ImeClana.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txt_ImeClana.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_ImeClana.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ImeClana.ForeColor = System.Drawing.Color.White;
            this.txt_ImeClana.Location = new System.Drawing.Point(63, 85);
            this.txt_ImeClana.Name = "txt_ImeClana";
            this.txt_ImeClana.Size = new System.Drawing.Size(216, 18);
            this.txt_ImeClana.TabIndex = 2;
            this.txt_ImeClana.Text = "Ime";
            this.txt_ImeClana.TextChanged += new System.EventHandler(this.txt_ImeClana_TextChanged);
            this.txt_ImeClana.Enter += new System.EventHandler(this.txt_ImeClana_Enter);
            this.txt_ImeClana.Leave += new System.EventHandler(this.txt_ImeClana_Leave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Freestyle Script", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.label1.Location = new System.Drawing.Point(114, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 42);
            this.label1.TabIndex = 3;
            this.label1.Text = "Nalog";
            // 
            // txt_prezimeClana
            // 
            this.txt_prezimeClana.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txt_prezimeClana.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_prezimeClana.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_prezimeClana.ForeColor = System.Drawing.Color.White;
            this.txt_prezimeClana.Location = new System.Drawing.Point(63, 144);
            this.txt_prezimeClana.Name = "txt_prezimeClana";
            this.txt_prezimeClana.Size = new System.Drawing.Size(216, 18);
            this.txt_prezimeClana.TabIndex = 6;
            this.txt_prezimeClana.Text = "Prezime";
            this.txt_prezimeClana.TextChanged += new System.EventHandler(this.txt_prezimeClana_TextChanged);
            this.txt_prezimeClana.Enter += new System.EventHandler(this.txt_prezimeClana_Enter);
            this.txt_prezimeClana.Leave += new System.EventHandler(this.txt_prezimeClana_Leave);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(30, 168);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(250, 1);
            this.panel1.TabIndex = 5;
            // 
            // txt_telefonClana
            // 
            this.txt_telefonClana.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txt_telefonClana.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_telefonClana.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_telefonClana.ForeColor = System.Drawing.Color.White;
            this.txt_telefonClana.Location = new System.Drawing.Point(64, 204);
            this.txt_telefonClana.Name = "txt_telefonClana";
            this.txt_telefonClana.Size = new System.Drawing.Size(216, 18);
            this.txt_telefonClana.TabIndex = 9;
            this.txt_telefonClana.Text = "Telefon";
            this.txt_telefonClana.Enter += new System.EventHandler(this.txt_telefonClana_Enter);
            this.txt_telefonClana.Leave += new System.EventHandler(this.txt_telefonClana_Leave);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(30, 228);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(250, 1);
            this.panel2.TabIndex = 8;
            // 
            // txt_emailClana
            // 
            this.txt_emailClana.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txt_emailClana.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_emailClana.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_emailClana.ForeColor = System.Drawing.Color.White;
            this.txt_emailClana.Location = new System.Drawing.Point(64, 263);
            this.txt_emailClana.Name = "txt_emailClana";
            this.txt_emailClana.Size = new System.Drawing.Size(216, 18);
            this.txt_emailClana.TabIndex = 12;
            this.txt_emailClana.Text = "Email";
            this.txt_emailClana.TextChanged += new System.EventHandler(this.txt_emailClana_TextChanged);
            this.txt_emailClana.Enter += new System.EventHandler(this.txt_emailClana_Enter);
            this.txt_emailClana.Leave += new System.EventHandler(this.txt_emailClana_Leave);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Location = new System.Drawing.Point(30, 287);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(250, 1);
            this.panel3.TabIndex = 11;
            // 
            // txt_adresaClana
            // 
            this.txt_adresaClana.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txt_adresaClana.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_adresaClana.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_adresaClana.ForeColor = System.Drawing.Color.White;
            this.txt_adresaClana.Location = new System.Drawing.Point(63, 320);
            this.txt_adresaClana.Name = "txt_adresaClana";
            this.txt_adresaClana.Size = new System.Drawing.Size(216, 18);
            this.txt_adresaClana.TabIndex = 15;
            this.txt_adresaClana.Text = "Adresa";
            this.txt_adresaClana.Enter += new System.EventHandler(this.txt_adresaClana_Enter);
            this.txt_adresaClana.Leave += new System.EventHandler(this.txt_adresaClana_Leave);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Location = new System.Drawing.Point(30, 344);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(250, 1);
            this.panel4.TabIndex = 14;
            // 
            // btn_sacuvaj
            // 
            this.btn_sacuvaj.ActiveBorderThickness = 1;
            this.btn_sacuvaj.ActiveCornerRadius = 20;
            this.btn_sacuvaj.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(203)))), ((int)(((byte)(219)))));
            this.btn_sacuvaj.ActiveForecolor = System.Drawing.Color.White;
            this.btn_sacuvaj.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.btn_sacuvaj.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.btn_sacuvaj.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_sacuvaj.BackgroundImage")));
            this.btn_sacuvaj.ButtonText = "Sačuvaj";
            this.btn_sacuvaj.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_sacuvaj.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_sacuvaj.ForeColor = System.Drawing.Color.White;
            this.btn_sacuvaj.IdleBorderThickness = 1;
            this.btn_sacuvaj.IdleCornerRadius = 20;
            this.btn_sacuvaj.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(184)))), ((int)(((byte)(206)))));
            this.btn_sacuvaj.IdleForecolor = System.Drawing.Color.White;
            this.btn_sacuvaj.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.btn_sacuvaj.Location = new System.Drawing.Point(89, 372);
            this.btn_sacuvaj.Margin = new System.Windows.Forms.Padding(5);
            this.btn_sacuvaj.Name = "btn_sacuvaj";
            this.btn_sacuvaj.Size = new System.Drawing.Size(127, 45);
            this.btn_sacuvaj.TabIndex = 17;
            this.btn_sacuvaj.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_sacuvaj.Click += new System.EventHandler(this.btn_sacuvaj_Click);
            // 
            // pcb_adresaClana
            // 
            this.pcb_adresaClana.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.pcb_adresaClana.Image = global::Forme.Properties.Resources.proba2House;
            this.pcb_adresaClana.Location = new System.Drawing.Point(30, 310);
            this.pcb_adresaClana.Name = "pcb_adresaClana";
            this.pcb_adresaClana.Size = new System.Drawing.Size(27, 28);
            this.pcb_adresaClana.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pcb_adresaClana.TabIndex = 13;
            this.pcb_adresaClana.TabStop = false;
            // 
            // pcb_emailClana
            // 
            this.pcb_emailClana.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.pcb_emailClana.Image = global::Forme.Properties.Resources.mailWhite;
            this.pcb_emailClana.Location = new System.Drawing.Point(30, 253);
            this.pcb_emailClana.Name = "pcb_emailClana";
            this.pcb_emailClana.Size = new System.Drawing.Size(27, 28);
            this.pcb_emailClana.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pcb_emailClana.TabIndex = 10;
            this.pcb_emailClana.TabStop = false;
            // 
            // pcb_telefonClana
            // 
            this.pcb_telefonClana.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.pcb_telefonClana.Image = global::Forme.Properties.Resources.phoneIcon_white;
            this.pcb_telefonClana.Location = new System.Drawing.Point(30, 194);
            this.pcb_telefonClana.Name = "pcb_telefonClana";
            this.pcb_telefonClana.Size = new System.Drawing.Size(27, 28);
            this.pcb_telefonClana.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pcb_telefonClana.TabIndex = 7;
            this.pcb_telefonClana.TabStop = false;
            // 
            // pcb_prezimeClana
            // 
            this.pcb_prezimeClana.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.pcb_prezimeClana.Image = global::Forme.Properties.Resources.userWhite1;
            this.pcb_prezimeClana.Location = new System.Drawing.Point(30, 134);
            this.pcb_prezimeClana.Name = "pcb_prezimeClana";
            this.pcb_prezimeClana.Size = new System.Drawing.Size(27, 28);
            this.pcb_prezimeClana.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pcb_prezimeClana.TabIndex = 4;
            this.pcb_prezimeClana.TabStop = false;
            // 
            // pcb_imeClana
            // 
            this.pcb_imeClana.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.pcb_imeClana.Image = global::Forme.Properties.Resources.userWhite1;
            this.pcb_imeClana.Location = new System.Drawing.Point(30, 75);
            this.pcb_imeClana.Name = "pcb_imeClana";
            this.pcb_imeClana.Size = new System.Drawing.Size(27, 27);
            this.pcb_imeClana.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pcb_imeClana.TabIndex = 0;
            this.pcb_imeClana.TabStop = false;
            // 
            // lbl_closeNalog
            // 
            this.lbl_closeNalog.AutoSize = true;
            this.lbl_closeNalog.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_closeNalog.ForeColor = System.Drawing.Color.White;
            this.lbl_closeNalog.Location = new System.Drawing.Point(281, 9);
            this.lbl_closeNalog.Name = "lbl_closeNalog";
            this.lbl_closeNalog.Size = new System.Drawing.Size(17, 20);
            this.lbl_closeNalog.TabIndex = 18;
            this.lbl_closeNalog.Text = "X";
            this.lbl_closeNalog.Click += new System.EventHandler(this.lbl_closeNalog_Click);
            // 
            // FrmKreirajNalog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(310, 445);
            this.Controls.Add(this.lbl_closeNalog);
            this.Controls.Add(this.btn_sacuvaj);
            this.Controls.Add(this.txt_adresaClana);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.pcb_adresaClana);
            this.Controls.Add(this.txt_emailClana);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.pcb_emailClana);
            this.Controls.Add(this.txt_telefonClana);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pcb_telefonClana);
            this.Controls.Add(this.txt_prezimeClana);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pcb_prezimeClana);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_ImeClana);
            this.Controls.Add(this.pnl_imeClana);
            this.Controls.Add(this.pcb_imeClana);
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmKreirajNalog";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmKreirajNalog";
            this.Load += new System.EventHandler(this.FrmKreirajNalog_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pcb_adresaClana)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcb_emailClana)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcb_telefonClana)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcb_prezimeClana)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcb_imeClana)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pcb_imeClana;
        private System.Windows.Forms.Panel pnl_imeClana;
        private System.Windows.Forms.TextBox txt_ImeClana;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_prezimeClana;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pcb_prezimeClana;
        private System.Windows.Forms.TextBox txt_telefonClana;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pcb_telefonClana;
        private System.Windows.Forms.TextBox txt_emailClana;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pcb_emailClana;
        private System.Windows.Forms.TextBox txt_adresaClana;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.PictureBox pcb_adresaClana;
        private Bunifu.Framework.UI.BunifuThinButton2 btn_sacuvaj;
        private System.Windows.Forms.Label lbl_closeNalog;
    }
}