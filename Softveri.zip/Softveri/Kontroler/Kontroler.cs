﻿using BazaZaposlenih;
using BrokerBazePodataka;
using Klasa;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Security.Cryptography;

namespace Kontroler
{

    public class Kontroler
    {
        
        public Zaposleni Zaposleni { get; set; }
        public GamingProizvod GamingProizvod { get; set; }

        private static Kontroler _instanca;
        private Baza storageKorisnik;

        public static Kontroler Instanca {
            get {
                if (_instanca == null) {
                    _instanca = new Kontroler();

                }
                return _instanca;
            }

        }
        private Kontroler()
        {
            storageKorisnik = new Baza();
        }



        /**Izmenjen Kontroler***/




        public object PrijaviSe(string korisnickoIme, string korisnickaSifra)
        {
            List<Zaposleni> lista = new List<Zaposleni>();
            lista = (List<Zaposleni>)Baza.listaZaposlenih;

            foreach (Zaposleni z in lista) {
                if (z.KorisnickoIme == korisnickoIme.Trim() && z.KorisnickaSifra == korisnickaSifra.Trim()) {
                    return z;
                }
            }
            return null;
        }


        //NALOG
        public object kreirajNalog(Nalog podaci)
        {
            try
            {
                Broker.Instanca.otvoriKonekciju();

                int uspesno = Broker.Instanca.Sacuvaj(podaci);
                if (uspesno == 1)
                {
                    return true;
                }
                return false;
            }
            finally
            {
                Broker.Instanca.zatvoriKonekciju();
            }
        }

        public object vratiProizvodjace()
        {
            try
            {
                Broker.Instanca.otvoriKonekciju();
                List<IDomenskiObjekat> proizvodjaci = Broker.Instanca.vratiSve(new Proizvodjac());
                return proizvodjaci.Cast<Proizvodjac>().ToList();
            }
            finally
            {
                Broker.Instanca.zatvoriKonekciju();
            }
        }

        public object PromeniNalog(Nalog n)
        {
            try
            {
                Broker.Instanca.otvoriKonekciju();
                int uspesno = Broker.Instanca.Promeni(n);
                if (uspesno == 1) {
                    return true;
                }
                return false;

            }
            finally {
                Broker.Instanca.zatvoriKonekciju();
            }
        }

        public bool ObrisiNalog(Nalog n)
        {
            try
            {
                Broker.Instanca.otvoriKonekciju();
                int uspesno = Broker.Instanca.Obrisi(n);
                if (uspesno == 1)
                {
                    return true;
                }
                return false;
            }
            finally
            {
                Broker.Instanca.zatvoriKonekciju();
            }
        }

        public object PretragaNaloga(string v)
        {
            try
            {
                Broker.Instanca.otvoriKonekciju();

                List<Nalog> nalozi = (List<Nalog>)Broker.Instanca.pronadjiObjekatIVratiGa(new Nalog(),v);
                return nalozi;

            }
            finally
            {
                Broker.Instanca.zatvoriKonekciju();
            }
        }

        public object napraviGamingProizvod2(GamingProizvod podaci)
        {
            try
            {
                Broker.Instanca.otvoriKonekciju();
                podaci.proizvodjac =(Proizvodjac) Broker.Instanca.vratiJedan(podaci.proizvodjac);

                int uspesno = Broker.Instanca.SacuvajSlozen(podaci);
                if (uspesno == 1) {
                    return true;
                }
                return false;
            }
            finally 
            {

                Broker.Instanca.zatvoriKonekciju();
            }
        }

        public object napraviGamingProizvod(GamingProizvod podaci)
        {
            try
            {
                Broker.Instanca.otvoriKonekciju();

                podaci.proizvodjac = (Proizvodjac) Broker.Instanca.vratiJedan(podaci.proizvodjac);
                int uspesno = Broker.Instanca.SacuvajSlozen(podaci);
                if (uspesno == 1) {
                    return true;
                }
                return false;
            }
            finally
            {
                Broker.Instanca.zatvoriKonekciju();
            }
        }

        public object izbrisiGamingProizvod(GamingProizvod podaci)
        {
            try
            {
                Broker.Instanca.otvoriKonekciju();
                int uspesno = Broker.Instanca.Obrisi(podaci);
                if (uspesno == 1) {
                    return true;
                }
                return false;
            }
            finally
            {
                Broker.Instanca.zatvoriKonekciju();
            }
        }

        public object promeniGamingProizvod(GamingProizvod podaci)
        {
            try
            {
                Broker.Instanca.otvoriKonekciju();
                int uspesno = Broker.Instanca.Promeni(podaci);
                if (uspesno == 1) {

                    return true;
                }
                return false;

            }
            finally {
                Broker.Instanca.zatvoriKonekciju();
            }
        }

        public IList<Nalog> vratiSveNaloge()
        {
            try
            {
                Broker.Instanca.otvoriKonekciju();

                List<IDomenskiObjekat> Nalozi = Broker.Instanca.vratiSve(new Nalog());


                List<Nalog> listaNaloga = Nalozi.Cast<Nalog>().ToList();

                return listaNaloga;
            }
            finally
            {
                Broker.Instanca.zatvoriKonekciju();
            }
        }


        //PROIZVOD
        public IList<GamingProizvod> ucitajGamingProizvode()
        {
            try
            {
                Broker.Instanca.otvoriKonekciju();

                List<IDomenskiObjekat> listaDomenskihObjekata = Broker.Instanca.vratiSve(new GamingProizvod());

                List<GamingProizvod> proizvodi = listaDomenskihObjekata.Cast<GamingProizvod>().ToList();

                foreach (GamingProizvod proizvod in proizvodi) {

                    proizvod.proizvodjac = (Proizvodjac) Broker.Instanca.vratiJedan(proizvod.proizvodjac);
                }


                return proizvodi;
            }
            finally
            {
                Broker.Instanca.zatvoriKonekciju();
            }
        }

        

        

        public object pretragaGamingProizvoda(string v)
        {
            try
            {
                Broker.Instanca.otvoriKonekciju();

                List<IDomenskiObjekat> proizvodi = Broker.Instanca.vratiSve(new GamingProizvod());
                List<GamingProizvod> listaProizvoda = proizvodi.Cast<GamingProizvod>().ToList();

                foreach (GamingProizvod proizvod in listaProizvoda) {
                    proizvod.proizvodjac = (Proizvodjac)Broker.Instanca.vratiJedan(proizvod.proizvodjac);
                }

                return listaProizvoda.FindAll(p => p.Naziv.ToLower().Contains(v.ToLower()) || p.model.ToLower().Contains(v.ToLower())
                                                || p.Proizvodjac_Ime.ToLower().Contains(v.ToLower()));

            }
            finally {
                Broker.Instanca.zatvoriKonekciju();
            }
        }


        


    }
}
