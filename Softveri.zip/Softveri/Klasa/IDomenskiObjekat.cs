﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Klasa
{
    public interface IDomenskiObjekat
    {
        string vratiNazivTabele();
        string vratiVrednostZaInsert();
        string vratiVrednostZaUpdate();
        string vratiVrednostZaDelete();
        string vratiUslov();
        string vratiUslovPoNazivu();
        string vratiAtributPretrazivanja();
        void postaviPocetnuVrednost();
        string vratiUslovZaPronalazenjeObjekata(string trazeni);
        
        void povecajVrednost(object vrednost);
        object kreirajObjekat();
        List<IDomenskiObjekat> vratiListu(SqlDataReader komanda);
    }
}
