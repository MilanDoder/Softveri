﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Klasa
{
    public class StavkaNarudzbenice
    {
        public int RedniBroj { get; set; }
        public int Kolicina { get; set; }
        
        public GamingProizvod proizvod { get; set; }




    }
}
