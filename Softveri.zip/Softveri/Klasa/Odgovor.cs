﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Klasa
{
    [Serializable]
    public class Odgovor
    {
        public bool Uspesnost { get; set; }
        public object Podaci { get; set; }
    }
}
