﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Klasa
{
    public class Narudzbenica : IDomenskiObjekat
    {

        public int SifraNarudzbenice { get; set; }
        public DateTime DatumOd { get; set; }
        public DateTime DatumDo { get; set; }
        public double UkupanIznos { get; set; }
        public Nalog Korisnik { get; set; }
        public List<StavkaNarudzbenice> stavke { get; set; }


        public object kreirajObjekat()
        {
            throw new NotImplementedException();
        }

        public void postaviPocetnuVrednost()
        {
            throw new NotImplementedException();
        }

        public void povecajVrednost(object vrednost)
        {
            throw new NotImplementedException();
        }

       

        public string vratiAtributPretrazivanja()
        {
            throw new NotImplementedException();
        }

        public List<IDomenskiObjekat> vratiListu(SqlDataReader komanda)
        {
            throw new NotImplementedException();
        }

        public string vratiNazivTabele()
        {
            throw new NotImplementedException();
        }

        public string vratiUslov()
        {
            throw new NotImplementedException();
        }

        public string vratiUslovPoNazivu()
        {
            throw new NotImplementedException();
        }

        public string vratiUslovZaPronalazenjeObjekata(string trazeni)
        {
            throw new NotImplementedException();
        }

        public string vratiVrednostZaDelete()
        {
            throw new NotImplementedException();
        }

        public string vratiVrednostZaInsert()
        {
            throw new NotImplementedException();
        }

        public string vratiVrednostZaUpdate()
        {
            throw new NotImplementedException();
        }
    }
}
