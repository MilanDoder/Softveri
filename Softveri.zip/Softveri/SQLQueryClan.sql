﻿CREATE TABLE Clan (
	ClanskiBroj int,
	ImePrezime varchar(255),
	KontaktTelefon varchar(15),
	Email varchar(50),
	Adresa varchar(255)
);
