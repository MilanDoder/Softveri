﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Klasa;
using System.Data.SqlClient;
using System.Data;
using System.ComponentModel;
using System.Configuration;

namespace BrokerBazePodataka
{
    /// <summary>
    ///     Vrsi komunikaciju bazom podataka
    ///     i vraca sve potrebne podatke iz baze podataka
    /// </summary>
    /// 
    
    public class Broker
    {

        private static Broker _instanca;
        private SqlConnection konekcija;
        private SqlTransaction transakcija;


        //konstruktorom odma imamo vezu sa bazom
        private Broker() {

            //string prom = ConfigurationManager.AppSettings["kljuc"];
            konekcija = new SqlConnection(ConfigurationManager.ConnectionStrings["konekcija"].ConnectionString);


        }

        public static Broker Instanca {

            get {
                if (_instanca == null) {
                       _instanca = new Broker();
                }
                return _instanca;

            }
        }

        public bool produziNalog(Nalog nalog)
        {
            try
            {
                konekcija.Open();
                SqlCommand komanda = konekcija.CreateCommand();
                string s = nalog.KontaktTelefon;
                string a = nalog.Email;
                Console.Write(s + "\t"+ a);
                komanda.CommandType = CommandType.Text;
                komanda.CommandText = $"UPDATE Clan SET   KontaktTelefon = {s}, Email  ='{nalog.Email}', Adresa = '{nalog.Adresa}'" +
                                        $"where ClanskiBroj  = {nalog.ClanskiBroj}";


                int result = komanda.ExecuteNonQuery();
                return result == 1;
                

            }
            catch (Exception)
            {

                throw new Exception("Sistem ne može da produži nalog!");
            }
            finally {
                konekcija.Close();
            }
        }

        public bool UnesiGamingProizvod(GamingProizvod g)
        {
            try
            {
                konekcija.Open();
                SqlCommand komanda = konekcija.CreateCommand();
                komanda.CommandText = "INSERT INTO Proizvod Values(@ProizvodID , @NazivProzivoda, @Karakteristike, @Model,"+
                                       "@Cena , @Kolicina , @ProzivodjacID)";
                komanda.CommandType = CommandType.Text;

                komanda.Parameters.Add("@ProizvodID", SqlDbType.Int).Value = g.proizvodID;
                komanda.Parameters.Add("@NazivProzivoda", SqlDbType.VarChar).Value = g.Naziv;
                komanda.Parameters.Add("@Karakteristike",SqlDbType.VarChar).Value = g.karakteristike;
                komanda.Parameters.Add("@Model", SqlDbType.VarChar).Value = g.model;
                komanda.Parameters.Add("@Cena",SqlDbType.Float).Value = g.cena;
                komanda.Parameters.Add("@Kolicina", SqlDbType.Int).Value =g.raspolozivoStanje;
                komanda.Parameters.Add("@ProzivodjacID", SqlDbType.Int).Value = g.proizvodjac.ProizvodjacID;

                int rezultat = komanda.ExecuteNonQuery();

                return rezultat == 1;

            }
            catch (Exception)
            {

                throw new Exception("Sistem ne moze da unese proizod!");
            }
            finally {
                konekcija.Close();
            }
        }

        

        public int vratiIDProizvodjaca(string naziv)
        {
            try
            {
                konekcija.Open();
                int id=-1;
                SqlCommand komanda = konekcija.CreateCommand();

                komanda.CommandText = $"Select ID From Proizvodjac where Naziv ='{naziv}' ";
                komanda.CommandType = CommandType.Text;


                SqlDataReader rez = komanda.ExecuteReader();

                while (rez.Read()) {
                    id = (int)rez["ID"];

                }
                return id;

            }
            catch (Exception)
            {

                throw;
            }
            finally {
                konekcija.Close();
            }
        }

        //Vrati sve proizvodjace
        public IList<Proizvodjac> vratiSveProizvodjace() {

            try
            {
                IList<Proizvodjac> proizvodjaci = new List<Proizvodjac>();
                konekcija.Open();

                //stvaranje upita 
                SqlCommand komanda = konekcija.CreateCommand();
                komanda.CommandText = "Select * FROM Proizvodjac";
                komanda.CommandType = System.Data.CommandType.Text;


                SqlDataReader podaci = komanda.ExecuteReader();

                while (podaci.Read()) {

                    Proizvodjac p = new Proizvodjac
                    {

                        ProizvodjacID = (int)podaci["ID"],
                        Naziv = podaci["Naziv"].ToString()
                    };
                    proizvodjaci.Add(p);

                }

                return proizvodjaci;

            }
            catch (Exception ex )
            {
                Console.Write(ex.Message);
                
            }
            finally {
                konekcija.Close();
            }
            return null;
        }

        public IList<GamingProizvod> ucitajGamingProizvode()
        {
            try
            {
                IList<GamingProizvod> proizvodi = new List<GamingProizvod>();
                konekcija.Open();
                SqlCommand komanda = konekcija.CreateCommand();
                komanda.CommandText = "Select ProizvodID, p.Naziv as Naziv_Proizvoda,Karakteristike,"+
                                       "Model,RaspolozivaKolicina,Cena ,pr.ID, pr.Naziv as Naziv_Proizvodjaca" +
                                       ",Adresa , BrojTelefona"+
                                       " From Proizvod as p JOIN Proizvodjac as pr ON (p.ProizvodjacID =pr.ID)";
                komanda.CommandType = CommandType.Text;

                SqlDataReader citac = komanda.ExecuteReader();

                while(citac.Read()){

                    GamingProizvod p = new GamingProizvod {

                        proizvodID = (int)citac["ProizvodID"],
                        Naziv = citac["Naziv_Proizvoda"].ToString(),
                        karakteristike = citac["Karakteristike"].ToString(),
                        model = citac["Model"].ToString(),

                        raspolozivoStanje = (int)citac["RaspolozivaKolicina"],
                        cena = Convert.ToInt64(citac["Cena"]),
                        proizvodjac = new Proizvodjac() {
                            ProizvodjacID = (int) citac["ID"],
                            Naziv = citac["Naziv_Proizvodjaca"].ToString(),
                            Adresa = citac["Adresa"].ToString(),
                            Telefon = citac["BrojTelefona"].ToString()
                        }
                        
                       

                    };
                    proizvodi.Add(p);

                }



                return proizvodi;
            }
            catch (Exception)
            {

                throw new Exception("Sistem ne moze da vrati proizvode");
            }
            finally {
                konekcija.Close();
            }

        }

        public bool ObrisiGamingProizvod(GamingProizvod proizvod)
        {
            try
            {
                konekcija.Open();
                SqlCommand komanda = konekcija.CreateCommand();

                komanda.CommandText = "DELETE FROM Proizvod " +
                                      $"WHERE ProizvodID = {proizvod.proizvodID}";

                komanda.CommandType = CommandType.Text;

                int rezultat = komanda.ExecuteNonQuery();
                return rezultat == 1;
            }
            catch (Exception)
            {

                throw;
            }
            finally {
                konekcija.Close();
            }

        }

        /// <summary>
        /// Obrisi nalog
        /// 
        /// Brisanje nalog na osnovu prosledjenog naloga
        /// </summary>
        /// <param name="n"></param>
        public bool ObrisiNalog(Nalog n)
        {
            try
            {
                konekcija.Open();
                SqlCommand komanda = konekcija.CreateCommand();
                komanda.CommandText = "DELETE   FROM Clan WHERE ClanskiBroj = " +
                                        $" {n.ClanskiBroj}";
                komanda.CommandType = CommandType.Text;

                int rezultat = komanda.ExecuteNonQuery();
                return rezultat == 1;
            }
            catch (Exception)
            {
                throw;
                
            }
            finally {
                konekcija.Close();
            }
        }

        

        /// <summary>
        /// Vracamo sve naloga
        /// </summary>
        /// <returns></returns>
        public IList<Nalog> vratiSveClanove()
        {
            try
            {
                IList<Nalog> clanovi = new List<Nalog>();
                konekcija.Open();
                SqlCommand komanda = konekcija.CreateCommand();
                komanda.CommandText = "Select * From Clan ";
                komanda.CommandType = System.Data.CommandType.Text;


                SqlDataReader citac = komanda.ExecuteReader();

                while (citac.Read()) {

                    Nalog n = new Nalog
                    {
                        ClanskiBroj = (int)citac["ClanskiBroj"],
                        ImePrezime = citac["ImePrezime"].ToString(),
                        KontaktTelefon = citac["KontaktTelefon"].ToString(),
                        Email = citac["Email"].ToString(),
                        Adresa = citac["Adresa"].ToString()

                    };
                    clanovi.Add(n);
                }
                return clanovi;
            }
            catch (Exception)
            {
                Console.Write("greska!");
                throw;
            }
            finally {
                konekcija.Close();
            }
        }
        /// <summary>
        /// Pretraga naloga
        /// </summary>
        /// <param name="kriterijum"></param>
        /// <returns></returns>
        public IList<Nalog> PretraziNaloge(string kriterijum)
        {
            try
            {
                IList<Nalog> nalozi = new List<Nalog>();
                konekcija.Open();
                SqlCommand komanda = konekcija.CreateCommand();
                komanda.CommandText = "SELECT *"+
                                      "FROM Clan"+
                                      $" WHERE Email LIKE '%{kriterijum}%' OR ClanskiBroj LIKE '%{kriterijum}%'"+
                                      $" OR ImePrezime LIKE '%{kriterijum}%'";
                komanda.CommandType = System.Data.CommandType.Text;


                SqlDataReader citac = komanda.ExecuteReader();

                while (citac.Read()) {

                    Nalog n = new Nalog
                    {
                        ClanskiBroj =(int) citac["ClanskiBroj"],
                        ImePrezime =  citac["ImePrezime"].ToString(),
                        KontaktTelefon = citac["KontaktTelefon"].ToString(),
                        Email = citac["Email"].ToString(),
                        Adresa= citac["Adresa"].ToString()

                    };
                    nalozi.Add(n);
                    
                }
                return nalozi;
            }
            catch (Exception)
            {

                Console.Write("Something wrong!");
                throw;
            }
            finally {
                konekcija.Close();
            }
        }

        public bool SacuvajClanskiNalog(Nalog nalog) {

            try
            {
                konekcija.Open();
                SqlCommand komanda = konekcija.CreateCommand();
                //Sintaksa parametrizovanog upita
                komanda.CommandText = $"INSERT INTO Clan VALUES(@ClanskiBroj,@ImePrezime,@KontaktTelefon,@Email,@Adresa)";
                komanda.CommandType = System.Data.CommandType.Text;
                //definisanje parametara upita
                komanda.Parameters.Add("@ClanskiBroj", SqlDbType.Int).Value = nalog.ClanskiBroj;
                komanda.Parameters.Add("@ImePrezime",SqlDbType.VarChar).Value = nalog.ImePrezime;
                komanda.Parameters.Add("@KontaktTelefon",SqlDbType.VarChar).Value = nalog.KontaktTelefon;
                komanda.Parameters.Add("@Email",SqlDbType.VarChar).Value = nalog.Email;
                komanda.Parameters.Add("@Adresa",SqlDbType.VarChar).Value = nalog.Adresa;



                int rezultat = komanda.ExecuteNonQuery();
                return rezultat == 1;

            }
            catch (Exception e)
            {
                
                throw e;
            }
            finally {
                konekcija.Close();
            }

        }

        public bool ispravnostClanskogBroja(int clanskiBroj) {

            try
            {
                konekcija.Open();
                SqlCommand komadna = konekcija.CreateCommand();
                komadna.CommandText = "Select * From Clan where ClanskiBroj = " + clanskiBroj.ToString();
                komadna.CommandType = System.Data.CommandType.Text;

                var rezultat = komadna.ExecuteNonQuery();
                
                if (rezultat == -1) {
                    return true; 
                }
                return false;

            }
            catch (Exception e)
            {

                throw new Exception("Greska!!!");
            }
            finally {
                konekcija.Close();
            }


        }


        

        public int vratiNajveciIDProizvoda() {
            

            try
            {
                konekcija.Open();
                SqlCommand komanda = konekcija.CreateCommand();
                komanda.CommandText = "Select MAX(ProizvodID) From Proizvod";
                komanda.CommandType = CommandType.Text;

                var rez = komanda.ExecuteScalar();
                if (rez == DBNull.Value) {
                    return 1;
                }
                return (int)rez + 1;

                
            }
            catch (Exception)
            {
                throw new Exception("Ne moze da pronadje najveci ID"); 
                
            }
            finally {
                konekcija.Close();
            }


            

        }


        //Genericke metode

        public List<IDomenskiObjekat> vratiSve(IDomenskiObjekat objekat)
        {

            SqlDataReader reader = null;
            try
            {
                SqlCommand komanda = konekcija.CreateCommand();
                string upit = $"Select  * from {objekat.vratiNazivTabele()}";
                komanda.CommandText = upit;
                reader = komanda.ExecuteReader();
                return objekat.vratiListu(reader);
            }
            finally
            {
                if (reader != null)
                {
                    reader.Close();
                }
            }
        }
        public IDomenskiObjekat vratiJedan(IDomenskiObjekat domenskiObjekat)
        {
            SqlDataReader citac = null;
            try
            {
                SqlCommand komanda = konekcija.CreateCommand();

                string upit = $"Select  * From {domenskiObjekat.vratiNazivTabele()} Where {domenskiObjekat.vratiUslov()} OR {domenskiObjekat.vratiUslovPoNazivu()}";
                komanda.CommandText = upit;
                citac = komanda.ExecuteReader();
                return domenskiObjekat.vratiListu(citac).First();
            }
            finally
            {
                if (citac != null)
                {
                    citac.Close();
                }
            }

        }

        public int SacuvajSlozen(IDomenskiObjekat objekat) {

            SqlCommand komanda  =konekcija.CreateCommand();

            string query = $"SELECT MAX({objekat.vratiAtributPretrazivanja()}) FROM {objekat.vratiNazivTabele()}";

            komanda.CommandText = query;

            var rest = komanda.ExecuteScalar();

            if (rest is DBNull)
            {
                objekat.postaviPocetnuVrednost();
            }
            else {
                
                objekat.povecajVrednost(rest);
            }

            //Nova komanda
            komanda = konekcija.CreateCommand();
            komanda.CommandText = "";
            query = $"INSERT INTO {objekat.vratiNazivTabele()} VALUES ({objekat.vratiVrednostZaInsert()})";
            komanda.CommandText = query;
            return komanda.ExecuteNonQuery();

        }

        public int Sacuvaj(IDomenskiObjekat objekat) {
            SqlCommand komanda = konekcija.CreateCommand();
            string query = $"INSERT INTO {objekat.vratiNazivTabele()} VALUES ({objekat.vratiVrednostZaInsert()})";

            komanda.CommandText = query;

            
            return komanda.ExecuteNonQuery();
        }

        public int Promeni(IDomenskiObjekat objekat) {
            SqlCommand komanda = konekcija.CreateCommand();
            string query = $"UPDATE {objekat.vratiNazivTabele()} SET {objekat.vratiVrednostZaUpdate()} WHERE {objekat.vratiUslov()}";

            komanda.CommandText = query;

            return komanda.ExecuteNonQuery();
        }

        public int Obrisi(IDomenskiObjekat objekat) {
            SqlCommand komanda = konekcija.CreateCommand();
            string query = $"DELETE  FROM {objekat.vratiNazivTabele()} WHERE {objekat.vratiUslov()}";
            komanda.CommandText = query;
            return komanda.ExecuteNonQuery();
        }

        public object pronadjiObjekatIVratiGa(IDomenskiObjekat objekat,string trazeni) {

            SqlDataReader citac = null;
            try
            {
                SqlCommand komanda = konekcija.CreateCommand();

                string query = $"SELECT *  FROM {objekat.vratiNazivTabele()} WHERE {objekat.vratiUslovZaPronalazenjeObjekata(trazeni)}";

                komanda.CommandText = query;
                citac = komanda.ExecuteReader();
                return objekat.vratiListu(citac);
            }
            finally {
                if (citac != null) {
                    citac.Close();
                }
            }



            return 1;
        }

        public void otvoriKonekciju() {
            konekcija.Open();
        }
        public void zatvoriKonekciju() {
            konekcija.Close();
        }
        public void pokreniTransakciju() {
            transakcija = konekcija.BeginTransaction();
        }

        public void potvrdiTransakciju() {
            transakcija.Commit();
        }
        public void ponistiTransakciju() {
            transakcija.Rollback();
        }

    }
}
